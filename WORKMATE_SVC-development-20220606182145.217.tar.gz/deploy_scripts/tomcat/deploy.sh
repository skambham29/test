#!/bin/bash
##########################################################################
# This Script runs all commands as the unix user specified in the        #
# deploydriver.properties file                                           #
#                                                                        #
#                                                                        #
# Created by: Greg Wobermin 4/20/2011                                    #
# Updated by: Dean Thomsen 3/24/2015                                     #
#                                                                        #
##########################################################################

validate_deployment () {
	if [[ ! -z ${DIAGNOSTICS_PING} && ${DIAGNOSTICS_PING} != "" ]]; then
	    # PING the server to validate that the application has deployed successfully and tomcat
	    # was successfully started.
	    curlcmd="http://${DEPLOY_HOST}${DIAGNOSTICS_PING}"
	    echo "INFO: testing server with ping using: curl ${curlcmd}"
	    response=`curl "${curlcmd}"`
	    echo "INFO: Response from ping ${response}"
		if [[ ${DIAGNOSTICS_PING_RESPONSE} == "" ]]; then
			DIAGNOSTICS_PING_RESPONSE="{\"ping\":{\"status\":\"OK\"}}"
		fi
	    if [[ ${response} != ${DIAGNOSTICS_PING_RESPONSE} ]]; then
		    echo "ERROR: START is not complete. Ping failed for ${curlcmd}. Expected: ${DIAGNOSTICS_PING_RESPONSE}"
			exit 1 
	    fi
	fi
	    
	#Now check to see that the expected version is actually installed and running
	if [[ ! -z ${BUILD_LABEL} && ${BUILD_LABEL} != "" ]]; then
		if [[ ${DIAGNOSTICS_CONFIG} != "" ]]; then 
		    curlcmd="http://${DEPLOY_HOST}${DIAGNOSTICS_CONFIG}"
		    echo "INFO: checking server config using: curl ${curlcmd}"
		    response=`curl "${curlcmd}" | grep "${BUILD_LABEL}"`
		    echo "INFO: Response from config: ${response}"
		    if [[ ${response} != *${BUILD_LABEL}* ]]; then
			    echo "ERROR: Server config does not have the correct build_label: \"${BUILD_LABEL}\""
			    exit 1 
			else
				echo "INFO: Server config verified as having the correct build_label: \"${BUILD_LABEL}\""
		    fi
		fi
	fi
}

echo "INFO: Now entering ${DEPLOY_DIR}/deploy_scripts/deploy.sh script"
echo "INFO: PWD is ${PWD}" 

ENVIRONMENT=`echo $1 | tr '[:upper:]' '[:lower:]'`
DEPLOY_PROPERTIES=$2
DEPLOY_DIR=$3
DB_NAME=$4

echo "DEPLOY_PROPERTIES = ${DEPLOY_PROPERTIES}" 
if [ -z "${DEPLOY_PROPERTIES}" ]; then
	echo "DEPLOY_PROPERTIES parameter is empty"
	exit 1
fi

for DEPLOY_PROPERTIES_FILE in $(echo $DEPLOY_PROPERTIES | sed "s/,/ /g"); do
	echo "INFO: Apply deploy properties file: ${DEPLOY_PROPERTIES_FILE}"
	. /${DEPLOY_PROPERTIES_FILE}
done

FUNCTION_SCRIPT="${DEPLOY_DIR}/deploy_scripts/deploy_functions.sh"
. ${FUNCTION_SCRIPT}

echo "UNIX_USER = ${UNIX_USER}" 
echo "DNSROOT = ${DNSROOT}" 
echo "CATALINA_BASE = ${CATALINA_BASE}" 
echo "WARS = ${WARS}" 

if [ -z "${WARS}" ]; then
	echo "No wars provided for deployment"
	exit 1
fi
if [ -z "${CATALINA_BASE}" ]; then
	echo "CATALINA_BASE parameter is empty"
	exit 1
fi

# change RESTART var to upper case if applicable
RESTART=`echo ${RESTART} | tr "[a-z]" "[A-Z]"`

# Deploy the wars and copy the properties files
DEPLOY_HOST=`hostname`
echo "DNSROOT=${DNSROOT}"
echo "NODE=${NODE}"
echo "DEPLOY_HOST = ${DEPLOY_HOST}"
  
update_wars ${WARS}

echo "INFO: Checking Java setup" 
export PATH=${JAVA_HOME}/jre/bin:${JAVA_HOME}/bin:${PATH}; 
echo JAVA_HOME ${JAVA_HOME}; 
which java >./cmd.log 2>&1
cat ./cmd.log

if [[ ${RESTART} == "TRUE" ]]; then
   	echo "INFO: STOPPING Tomcat running on ${DEPLOY_HOST}" 
   	export PATH=${JAVA_HOME}/jre/bin:${JAVA_HOME}/bin:${PATH}; 
    if ! ${CATALINA_BASE}/bin/shutdown.sh 10 -force 1>./cmd.log 2>&1; then
		cat ./cmd.log
		echo "ERROR: shutdown failed - will try to kill the PID now"
	fi
	#Make sure it's dead by locating and killing the process, but wait 5 seconds to give the shutdown time to complete
	sleep 5
	echo "INFO: Checking for the catalina processes running on the server and killing them"
	for pid in $(ps -ef | grep catalina.startup | grep -v grep | awk '{print $2}'); do
		echo "killing process: $pid"; kill -9 $pid >./cmd.log 2>&1; cat ./cmd.log; 
	done
	echo "INFO: Checking for processes using port 8080"
	for pid in $(netstat -nlp 2>/dev/null | grep 8080 | grep tcp | grep LISTEN | awk -F"/" '{ print $1 }' | awk '{ print $7}'); do 
		echo "killing process: $pid"; kill -9 $pid >./cmd.log 2>&1; cat ./cmd.log; 
	done
    echo "INFO: STOP complete for tomcat running on ${DEPLOY_HOST}" 
fi
  
# Remove War Files
for WAR in ${WARS}; do
   	DEPLOY=`echo ${WAR} | sed -e 's/.war//g'`
   	echo "INFO: Removing ${WAR} from ${DEPLOY_HOST}" 
	if ! rm -rf ${CATALINA_BASE}/webapps/${DEPLOY} 1>./cmd.log 2>&1 ; then
		cat ./cmd.log
   		echo "WARN: Was not able to remove \"${WAR}\" from \"${DEPLOY_HOST}\""
   	else
   		cat ./cmd.log
   	fi
done

# Deploy War Files
for WAR in ${WARS}; do
   	echo "INFO: Deploying ${WAR} to ${DEPLOY_HOST}" 
	if ! cp ${DEPLOY_DIR}/dist/${WAR} ${CATALINA_BASE}/webapps 1>./cmd.log 2>&1 ; then
   		echo "ERROR: Was not able to deploy \"${WAR}\" to \"${DEPLOY_HOST}\""
		cat ./cmd.log
   	    exit 1
   	fi
   	cat ./cmd.log
done

# Deploy L3APPS files
for FILE in ${FILES}; do
   	echo "INFO: Copying ${FILE} to ${DNSROOT}${NODE}_${ENVIRONMENT}/L3APPS/${FILE} directory on ${DEPLOY_HOST}" 
   	if [ -f ${DEPLOY_DIR}/env_config/${ENVIRONMENT}_${FILE} ]; then
		if ! cp ${DEPLOY_DIR}/env_config/${ENVIRONMENT}_${FILE} ${CATALINA_BASE}/L3APPS/${FILE}  1>./cmd.log 2>&1 ; then
			echo "WARN: Was not able to copy \"${FILE}\" to \"${DEPLOY_HOST}\"" 
    	fi
    else
		if ! cp ${DEPLOY_DIR}/env_config/default_${FILE} ${CATALINA_BASE}/L3APPS/${FILE}  1>./cmd.log 2>&1 ; then
			echo "WARN: Was not able to copy \"default_${FILE}\" to \"${DEPLOY_HOST}\"" 
    	fi
    fi
	cat ./cmd.log
done

# Restart Server
if [[ ${RESTART} == "TRUE" ]]; then
   	echo "INFO: STARTING Tomcat running on ${DEPLOY_HOST}" 
   	export PATH=${JAVA_HOME}/jre/bin:${JAVA_HOME}/bin:${PATH}; 
	if ! ${CATALINA_BASE}/bin/startup.sh 1>./cmd.log 2>&1; then
    	echo "ERROR: Was not able to start tomcat"
    fi
    cat ./cmd.log
        
    # Wait 30 seconds for server to start and then validate that it was successfully restarted
    sleep 30s
    validate_deployment
    
   	echo "INFO: START complete for tomcat running on ${DEPLOY_HOST}" 
fi

echo "INFO: Now leaving ${DEPLOY_DIR}/deploy_scripts/deploy.sh script"
