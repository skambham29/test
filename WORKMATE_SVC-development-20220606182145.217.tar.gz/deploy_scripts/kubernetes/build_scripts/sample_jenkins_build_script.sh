# This is a sample script that can be included in your jenkins build job to setup the properties files
# and deployment scripts.

# Create the properties files and deploy scripts for a Kubernetes deployment via a Unix Intermediary server
rm -rf sl.common
git clone git@l3git:sl.common
cd sl.common
git checkout development
cd ..

#Add build_label to default_deploydriver.properties
sed -i "s/@@build_version@@/${ITCDM_BUILD_DATA_VERSION}/g;" ${env_properties_directory}/default_deploydriver.properties;

mkdir -p ${deploy_scripts_directory}
cp sl.common/deploy_scripts/common/*.sh ${deploy_scripts_directory}
cp sl.common/deploy_scripts/kubernetes/*.sh ${deploy_scripts_directory}
echo "common deploy scripts setup complete"
