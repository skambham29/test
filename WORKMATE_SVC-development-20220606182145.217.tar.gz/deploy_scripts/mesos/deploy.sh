##########################################################################
# This Script runs all commands as the unix user specified in the        #
# default_deploydriver.properties file                                   #
#                                                                        #
#                                                                        #
# Created by: Dean Thomsen 8/18/2018                                     #
#                                                                        #
#########################################################################

echo "INFO: Now entering \"${PWD}/deploy.sh\" script"

ENVIRONMENT=$1
DEPLOY_PROPERTIES=$2
DEPLOY_DIR=$3

# Source properties files
for DEPLOY_PROPERTIES_FILE in $(echo $DEPLOY_PROPERTIES | sed "s/,/ /g"); do
    echo "INFO: Apply deploy properties file: ${DEPLOY_PROPERTIES_FILE}"
    . ${DEPLOY_PROPERTIES_FILE}
done

if [[ ${DEPLOY_FILE} == "" ]]; then
	DEPLOY_FILE="${ENVIRONMENT}-deploy.json"
fi

### Update the tags and deploy to Marathon
if ! sed -i "s/@@artifact_name@@/${artifact_name}/g; s|@@artifact_url@@|${artifact_url}|g" ${DEPLOY_DIR}/env_config/${DEPLOY_FILE}; then
    echo "jar_name and url_link substitution failed"
    exit 1
fi

if ! curl -H "Accept: application/json" -H "Content-Type: application/json" -X PUT ${MESOS_URL} -d @${DEPLOY_DIR}/env_config/${DEPLOY_FILE}; then
    echo "Failed to deploy to mesos!"
    exit 1
fi
exit 0