#!/bin/bash
##########################################################################
# This Script runs all commands as the unix user specified in the        #
# deploydriver.properties file                                           #
#                                                                        #
#                                                                        #
# Created by: Greg Wobermin 4/20/2011                                    #
# Updated by: Dean Thomsen 3/24/2015                                     #
#                                                                        #
##########################################################################

validate_deployment () {
	if [[ ${DIAGNOSTICS_PING} != "" ]]; then
	    # PING the server to validate that the application has deployed successfully and jboss
	    # was successfully started.
	    curlcmd="http://${DEPLOY_HOST}${DIAGNOSTICS_PING}"
	    echo "INFO: testing server with ping using: curl ${curlcmd}"
	    response=`curl "${curlcmd}"`
	    echo "INFO: Response from ping ${response}"
		if [[ ${DIAGNOSTICS_PING_RESPONSE} == "" ]]; then
			DIAGNOSTICS_PING_RESPONSE="{\"ping\":{\"status\":\"OK\"}}"
		fi
	    if [[ ${response} != ${DIAGNOSTICS_PING_RESPONSE} ]]; then
		    echo "ERROR: START is not complete. Ping failed for ${curlcmd}. Expected: ${DIAGNOSTICS_PING_RESPONSE}"
			exit 1 
	    fi
	fi
	    
	#Now check to see that the expected version is actually installed and running
	if [[ ${BUILD_LABEL} != "" ]]; then
		if [[ ${DIAGNOSTICS_CONFIG} != "" ]]; then 
		    curlcmd="http://${DEPLOY_HOST}${DIAGNOSTICS_CONFIG}"
		    echo "INFO: checking server config using: curl ${curlcmd}"
		    response=`curl "${curlcmd}" | grep "${BUILD_LABEL}"`
		    echo "INFO: Response from config: ${response}"
		    if [[ ${response} != *${BUILD_LABEL}* ]]; then
			    echo "ERROR: Server config does not have the correct build_label: \"${BUILD_LABEL}\""
			    exit 1 
			else
				echo "INFO: Server config verified as having the correct build_label: \"${BUILD_LABEL}\""
		    fi
		fi
	fi
}

echo "INFO: Now entering ${PANDA_DIR}/deploy_scripts/deploy.sh script"
echo "INFO: PWD is ${PWD}" 

ENVIRONMENT=`echo $1 | tr '[:upper:]' '[:lower:]'`
DEPLOY_PROPERTIES=$2
PANDA_DIR=$3
#Make sure these variables are defined. They will be set (or not) by the deploy properties files.
DIAGNOSTICS_PING=""
DIAGNOSTICS_CONFIG=""
DIAGNOSTICS_PING_RESPONSE=""
for DEPLOY_PROPERTIES_FILE in $(echo $DEPLOY_PROPERTIES | sed "s/,/ /g"); do
	echo "INFO: Apply deploy properties file: ${DEPLOY_PROPERTIES_FILE}"
	. ${DEPLOY_PROPERTIES_FILE}
done

FUNCTION_SCRIPT="${PANDA_DIR}/deploy_scripts/deploy_functions.sh"
. ${FUNCTION_SCRIPT}

echo "UNIX_USER = ${UNIX_USER}" 
echo "EARS = ${EARS}" 

# change RESTART var to upper case if applicable
RESTART=`echo ${RESTART} | tr "[a-z]" "[A-Z]"`

# Deploy the wars and copy the properties files
DEPLOY_HOST=`hostname`
echo "DEPLOY_HOST = ${DEPLOY_HOST}"
  
#echo "INFO: Checking Java setup" 
#export PATH=${JAVA_HOME}/jre/bin:${JAVA_HOME}/bin:${PATH}; 
#echo JAVA_HOME ${JAVA_HOME}; 
#which java >./cmd.log 2>&1
#cat ./cmd.log

if [[ ${RESTART} == "TRUE" ]]; then
   	echo "INFO: STOPPING JBOSS running on ${DEPLOY_HOST}" 
   	export PATH=${JAVA_HOME}/jre/bin:${JAVA_HOME}/bin:${PATH}; 
	echo "INFO: Checking for the jboss processes running on the server"
	ps -ef | grep jboss | grep -v grep >./cmd.log 2>&1
	cat ./cmd.log
	PROC=`tail ./cmd.log | grep standalone-prod.xml | awk '{ print $2}' | tr -d '[:space:]'`
	if [[ ${PROC} != "" ]]; then
		#Found a jboss process - kill it
		echo "killing process: ${PROC}"
		kill -9 ${PROC} >./cmd.log 2>&1
		cat ./cmd.log
	fi
    echo "INFO: STOP complete for jboss running on ${DEPLOY_HOST}" 
fi
  
# Backup Ear Files
for EAR in ${EARS}; do
   	echo "INFO: Backup up ${EAR} on ${DEPLOY_HOST}" 
   	DATE=`date +%Y%m%d`
	if ! cp ${JBOSS_BASE}/${JBOSS_DEPLOYMENTS}/${EAR} ${JBOSS_BASE}/${JBOSS_DEPLOYMENTS}/${EAR}.${DATE} 1>./cmd.log 2>&1 ; then
		cat ./cmd.log
   		echo "WARN: Was not able to backup \"${EAR}\" on \"${DEPLOY_HOST}\""
   	else
   		cat ./cmd.log
   	fi
done

# Deploy Ear Files
for EAR in ${EARS}; do
   	echo "INFO: Deploying ${EAR} to ${DEPLOY_HOST}" 
	if ! cp ${PANDA_DIR}/dist/${EAR} ${JBOSS_BASE}/${JBOSS_DEPLOYMENTS}/${EAR} 1>./cmd.log 2>&1 ; then
   		echo "ERROR: Was not able to deploy \"${EAR}\" to \"${DEPLOY_HOST}\""
		cat ./cmd.log
   	    exit 1
   	fi
   	cat ./cmd.log
done

# Restart Server
if [[ ${RESTART} == "TRUE" ]]; then
   	echo "INFO: STARTING jboss running on ${DEPLOY_HOST}" 
   	#export PATH=${JAVA_HOME}/jre/bin:${JAVA_HOME}/bin:${PATH}; 
	if ! nohup ./${JBOSS_BASE}/bin/standalone.sh -c standalone-prod.xml & 1>./cmd.log 2>&1; then
    	echo "ERROR: Was not able to start jboss"
    fi
    cat ./cmd.log
        
    # Wait 30 seconds for server to start and then validate that it was successfully restarted
    sleep 30s
    validate_deployment
    
   	echo "INFO: START complete for jboss running on ${DEPLOY_HOST}" 
fi

echo "INFO: Now leaving ${PANDA_DIR}/deploy_scripts/deploy.sh script"
