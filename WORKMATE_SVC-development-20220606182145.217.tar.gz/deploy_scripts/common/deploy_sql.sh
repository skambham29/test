#!/bin/bash
##########################################################################
# This Script looks for the presence of SQL scripts (DDL, DML) and then  #
# uses sqlplus to execute those scripts.                                 #
#                                                                        #
# Note that this script expects a sqlfiles.tar in the dist directory. It #
# will untar that file and execute the scripts that match the filenames  #
# defined in the deploydriver properties file                            #
#                                                                        #
# Created by: Dean Thomsen 7/18/2018                                     #
# Updated by: Dean Thomsen d/mm/yyyy                                     #
#                                                                        #
##########################################################################

execute_sql_script() {
	SCRIPT_NAME=$1
	echo "INFO: Executing script: ${SCRIPT_NAME}"
	CMD=`whereis sqlplus`
	if [ $CMD == "sqlplus:" ]; then 
		echo "ERROR: sqlplus not installed"
	else
		echo "INFO: sqlplus uid/pwd@${DB_NAME} @${SCRIPT_NAME}"
	fi 		
}

echo "INFO: Now entering deploy_scripts/deploy_sql.sh"
ENVIRONMENT=`echo $1 | tr '[:upper:]' '[:lower:]'`
DEPLOY_PROPERTIES=$2
DEPLOY_DIR=$3

echo "INFO: PWD is ${PWD}"
echo "INFO: DB_NAME is ${DB_NAME}"  
echo "INFO: SQL_DDL_SCRIPT is ${SQL_DDL_SCRIPT}"  
echo "INFO: SQL_DML_SCRIPT is ${SQL_DML_SCRIPT}"  

if [ -f ${DEPLOY_DIR}/dist/sqlfiles.tar ]; then
	cd ${DEPLOY_DIR}/dist
	tar -xf sqlfiles.tar
	if [ -d ${DEPLOY_DIR}/dist/ddl ]; then
		cd ${DEPLOY_DIR}/dist/ddl;
		if [ -f ${SQL_DDL_SCRIPT} ]; then
			execute_sql_script "${SQL_DDL_SCRIPT}"
		else
			echo "INFO: DDL script: ${SQL_DDL_SCRIPT} does not exist. Skipping DDL execution."
		fi
	else
		echo "INFO: DDL directory does not exist. Skipping DDL execution."
	fi
	
	if [ -d ${DEPLOY_DIR}/dist/dml ]; then
		cd ${DEPLOY_DIR}/dist/dml;
		if [ -f ${SQL_DML_SCRIPT} ]; then
			execute_sql_script "${SQL_DML_SCRIPT}"
		else
			echo "INFO: DML script: ${SQL_DML_SCRIPT} does not exist. Skipping DML execution."
		fi
	else
		echo "INFO: DML directory does not exist. Skipping DML execution."
	fi
else
	echo "INFO: No sqlfiles.tar. Skipping SQL execution."
fi
cd ${PWD}
echo "INFO: Now leaving deploy_scripts/deploy_sql.sh"
exit 0