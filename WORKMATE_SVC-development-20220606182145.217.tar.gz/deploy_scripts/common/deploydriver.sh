#!/bin/bash
################################################################################
#                                                                              #
# This script is a common wrapper script for the steps to complete a           #
# deployment of an instance of an enterprise service.  This wrapper will       #
# call the following scripts as the UNIX_USER:                                 #
#    deploy                                                                    #
#                                                                              #
# Arguments:                                                                   #
#  $1 - The environment to deploy to                                           #
#                                                                              #
# Modified: Dean Thomsen 8/25/2018                                             #
#                                                                              #
################################################################################

execute_deploy_script() {
	ENVIRONMENT=$1
	DEPLOY_PROPERTIES=$2
	PWD=$3
	PASSWORDS=$4
	INPUTS=$5
	echo ""
	echo "========================================="
	echo "INFO: Executing deploy.sh as ${UNIX_USER} on host ${HOSTNAME}" 
	if ! /usr/bin/sudo su - ${UNIX_USER} -c "${SCRIPTSDIR}/deploy.sh ${ENVIRONMENT} ${DEPLOY_PROPERTIES} ${PWD} ${PASSWORDS} ${INPUTS}"; then
		echo "ERROR: deploydriver.sh: deploy.sh script failed to complete successfully"
		echo "========================================="
		echo ""
		exit 1
	fi
	echo "INFO: deploydriver.sh: deploy.sh script completed successfully"
	echo "========================================="
	echo ""
}

if [ $# -lt 1 ]; then
    echo "usage: $0 environment"
    exit 1
fi

ENVIRONMENT=$1
PASSWORDS=$2
INPUTS=$3
HOSTNAME=`hostname`

echo ""
echo ""
echo "INFO: Hostname is ${HOSTNAME}"
echo "INFO: Environment is ${ENVIRONMENT}"
echo "INFO: PWD is ${PWD}"
  
#Setup to use both the default_deploydriver.properties and environment specific environment properties if they exist
ENV_CONFIG_DIR=${PWD}/env_config
echo "INFO: ENV_CONFIG_DIR is ${ENV_CONFIG_DIR}"
if [ -f "${ENV_CONFIG_DIR}/default_deploydriver.properties" ]; then
    echo "INFO: default_deploydriver file found, setting up to include it"
    DEPLOY_PROPERTIES="${ENV_CONFIG_DIR}/default_deploydriver.properties"
fi

if [ -f "${ENV_CONFIG_DIR}/${ENVIRONMENT}_deploydriver.properties" ]; then
    echo "INFO: ENV specific deploydriver.properties file found, using \"${ENVIRONMENT}_deploydriver.properties\""
    if [[ ${DEPLOY_PROPERTIES} != "" ]]; then
    	DEPLOY_PROPERTIES="${DEPLOY_PROPERTIES},${ENV_CONFIG_DIR}/${ENVIRONMENT}_deploydriver.properties"
    else
    	DEPLOY_PROPERTIES="${ENV_CONFIG_DIR}/${ENVIRONMENT}_deploydriver.properties"
    fi
fi
  
echo "INFO: DEPLOY_PROPERTIES is ${DEPLOY_PROPERTIES}"

echo "INFO: Performing dos2unix on properties files"

for file in `find ./env_config -type f`; do
	dos2unix --quiet $file $file 1>./cmd.log 2>&1
	cat ./cmd.log
done

for DEPLOY_PROPERTIES_FILE in $(echo $DEPLOY_PROPERTIES | sed "s/,/ /g"); do
	echo "INFO: Apply deploy properties file: ${DEPLOY_PROPERTIES_FILE}"
	. /${DEPLOY_PROPERTIES_FILE}
done

if [ -z ${SCRIPTSDIR} ]; then
	SCRIPTSDIR=${PWD}/deploy_scripts
fi
echo "INFO: SCRIPTSDIR is ${SCRIPTSDIR}"
if [ -z ${UNIX_USER} ]; then
	UNIX_USER="envuser"
fi
echo "INFO: UNIX_USER is ${UNIX_USER}"

echo "INFO: Performing dos2unix on deploy script files in ${SCRIPTSDIR}"

for file in `find ${SCRIPTSDIR} -type f`; do
	dos2unix --quiet $file $file 1>./cmd.log 2>&1
	cat ./cmd.log
done

# Changing Permissions so $UNIX_USER can access
chmod -R o+rw ${PWD}
chmod +x ${SCRIPTSDIR}/deploy.sh

# Check for pre,deploy,and post scripts
if [ ! -f ${SCRIPTSDIR}/deploy.sh ]; then
	echo "ERROR: ${SCRIPTSDIR}/deploy.sh does not exist. Exiting"
fi

#Start the deployment Tasks
export ENVIRONMENT=${ENVIRONMENT}
if [[ ! -z ${SQL_EXECUTION_SERVER} && "${HOSTNAME}" == "${SQL_EXECUTION_SERVER}" ]]; then
	echo "INFO: Running on the SQL Execution server ${SQL_EXECUTION_SERVER}"
	if [ -f ${SCRIPTSDIR}/deploy_sql.sh ]; then 
		echo "INFO: Executing deploy_sql.sh as ${UNIX_USER}" 
		if ! /usr/bin/sudo su - ${UNIX_USER} -c "${SCRIPTSDIR}/deploy_sql.sh ${ENVIRONMENT} ${DEPLOY_PROPERTIES} ${PWD}"; then
		    echo "ERROR: deploydriver.sh: deploy_sql.sh script failed to complete successfully"
		    exit 1
		fi
		echo "INFO: deploydriver.sh: deploy_sql.sh script completed successfully"
	else
		echo "ERROR: running on SQL Execution Server, but deploy_sql.sh script does not exist"
		exit 1
	fi
else
	echo "INFO: NOT running on the SQL Execution server ${SQL_EXECUTION_SERVER} - not executing deploy_sql.sh"
fi

if [[ -z ${DNSROOT} ]]; then
	execute_deploy_script ${ENVIRONMENT} ${DEPLOY_PROPERTIES} ${PWD} ${PASSWORDS} ${INPUTS}
else
	for DNSROOT_NAME in $(echo ${DNSROOT} | sed "s/,/ /g"); do
		echo "INFO: DNSROOT name: ${DNSROOT_NAME}"
		if [[ -z ${DNSROOT_NAME} || ${HOSTNAME} == ${DNSROOT_NAME}* ]]; then
		    execute_deploy_script ${ENVIRONMENT} ${DEPLOY_PROPERTIES} ${PWD} ${PASSWORDS} ${INPUTS}
		else
			echo "INFO: NOT running on a host (${HOSTNAME}) as DNSROOT is (${DNSROOT_NAME}) - not executing deploy.sh"
		fi
	done
fi
echo "exit 0"
exit 0
