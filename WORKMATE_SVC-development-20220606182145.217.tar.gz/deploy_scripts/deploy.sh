##########################################################################
# This Script runs all commands as the unix user specified in the        #
# default_deploydriver.properties file                                   #
#                                                                        #
#                                                                        #
# Created by: Dean Thomsen 8/18/2018                                     #
#                                                                        #
#########################################################################

logInfo() {
    dt=`date +"%Y-%m-%d %T"`
    printf "\n${dt} INFO: $1\n"
}
logError() {
    dt=`date +"%Y-%m-%d %T"`
    printf "\n${dt} ERROR: $1\n"
}

#The point of this method is to test the result of the command execution and fail the script if there is an error
execute_kubectl() {
    logInfo "====== Executing: $1" 
    if ! $1 1>./cmd.log 2>&1; then
        if [ -z $2 ] || [ "$2" != "non-fatal" ]; then
            logError "Error executing kubectl command: $1"
            cat ./cmd.log
            exit 1
        fi
        logError "NON-FATAL ERROR: executing kubectl command: $1"
    fi
    cat ./cmd.log
}

logInfo "Now entering \"${PWD}/deploy.sh\" script"

ENVIRONMENT=$1
DEPLOY_PROPERTIES=$2
DEPLOY_DIR=$3

for DEPLOY_PROPERTIES_FILE in $(echo $DEPLOY_PROPERTIES | sed "s/,/ /g"); do
    logInfo "Apply deploy properties file: ${DEPLOY_PROPERTIES_FILE}"
    . ${DEPLOY_PROPERTIES_FILE}
done

export APP_API_NAME=${APP_NAME}-${APP_SPACE}
if [[ -z ${DOCKER_USERNAME} ]]; then
	export DOCKER_USERNAME="gitlab-ci-token"
fi
logInfo "APP_API_NAME=${APP_API_NAME}"
logInfo "Deploying image: ${REG_IMAGE}"

#kubernetes won't allow variables in the yaml files so using envsubst workaround so we can use them 
logInfo "execute variable substitution"
env envsubst < ${DEPLOY_DIR}/env_config/deployment.tmpl > ${DEPLOY_DIR}/deployment.yaml
env envsubst < ${DEPLOY_DIR}/env_config/service.tmpl > ${DEPLOY_DIR}/service.yaml
env envsubst < ${DEPLOY_DIR}/env_config/ingress.tmpl > ${DEPLOY_DIR}/ingress.yaml

#Show yaml files to validate they have been correctly updated with the properties
logInfo "===== Show deployment.yaml to validate that it has been correctly updated with the properties"
cat ${DEPLOY_DIR}/deployment.yaml
logInfo "===== Show service.yaml to validate that it has been correctly updated with the properties"
cat ${DEPLOY_DIR}/service.yaml
logInfo "===== Show ingress.yaml to validate that it has been correctly updated with the properties"
cat ${DEPLOY_DIR}/ingress.yaml

#todo: put some sort of validation on each of these commands to make sure they execute correctly

#set kubernetes credentials
logInfo "===== Set kubernetes credentials"
#execute_kubectl "kubectl config set-cluster mine --server=${K8S_CLUSTER_URL} --insecure-skip-tls-verify=true"
#execute_kubectl "kubectl config set-credentials mine --token=${K8S_TOKEN}"
#execute_kubectl "kubectl config set-context mine --cluster=mine --user=mine --namespace=${K8S_NAMESPACE}"
#execute_kubectl "kubectl config use-context mine"
execute_kubectl "kubectl config use-context kubernetes-admin@kubernetes"
execute_kubectl "kubectl config view"
          
#kube secret to access docker registry 
logInfo "===== Recreate the kube secret to access docker registry"
execute_kubectl "kubectl delete secret ${REG_SECRET} -n ${K8S_NAMESPACE}" "non-fatal"
execute_kubectl "kubectl create secret docker-registry ${REG_SECRET} --docker-server=${REG_BASE_URI} --docker-username=${DOCKER_USERNAME} --docker-password=${REG_TOKEN} --docker-email=${APP_OWNER_EMAIL} -n ${K8S_NAMESPACE}"
                
#Does the deployment already exist?
logInfo "Does the deployment already exist?"
execute_kubectl "kubectl get deployment ${APP_API_NAME} -n ${K8S_NAMESPACE}" "non-fatal"
response=`cat ./cmd.log`
if [[ -z ${ROLLING_UPDATE} || ${ROLLING_UPDATE} == "false" || ${response} == *"NotFound"* ]]; then
    #using delete/create on deployment to force docker deployment 
    if [[ ${response} != *"NotFound"* ]]; then
        #Deployment already exists, so delete it
        logInfo "Delete existing deployment ${APP_API_NAME}"
        execute_kubectl "kubectl delete -f ${DEPLOY_DIR}/deployment.yaml"
    fi
    logInfo "Create deployment ${APP_API_NAME}"
    execute_kubectl "kubectl create -f ${DEPLOY_DIR}/deployment.yaml"
    execute_kubectl "kubectl apply -f ${DEPLOY_DIR}/service.yaml -f ${DEPLOY_DIR}/ingress.yaml"
    execute_kubectl "kubectl -n ${K8S_NAMESPACE} describe ingress ${APP_API_NAME}"
else
	# Get the current image
	execute_kubectl "kubectl -n ${K8S_NAMESPACE} get deployment/${APP_API_NAME} -o=jsonpath='{..image}'" "non-fatal"
	imageName=`cat ./cmd.log`	
	# If the image has not changed, execute a force rolling bounce
	echo ""
	echo "Image to be deployed (REG_IMAGE)="${REG_IMAGE}
	echo "Image currently deployed (imageName)="${imageName}
	if [[ ${imageName} == *${REG_IMAGE}* ]]; then
		echo "Existing image so doing a rollout restart"
		execute_kubectl "kubectl -n ${K8S_NAMESPACE} rollout restart deployment/${APP_API_NAME}" 
	else
		echo "Applying new image"
	    #Execute a rolling update of the deployment to the new image
	    #This will not update any of the applications confgurations. So if any of the yaml files (deployment, service, ingress)
	    #have been updated then you need to not do a rolling deployment
		logInfo "Create deployment ${APP_API_NAME}"
		execute_kubectl "kubectl apply -f ${DEPLOY_DIR}/deployment.yaml"
		logInfo "Create service and ingress ${APP_API_NAME}"
		execute_kubectl "kubectl apply -f ${DEPLOY_DIR}/service.yaml -f ${DEPLOY_DIR}/ingress.yaml"
	fi
fi

#Wait for deployment to complete
sleep 10s
# Validate the image
execute_kubectl "kubectl get pods -l=app=${APP_API_NAME} -n ${K8S_NAMESPACE}" "non-fatal"
error=`grep InvalidImageName ./pods.log`
if [[ "$error" == *"InvalidImageName"* ]]; then
    logError "Failing deployment due to Invalid Image Name"
    exit 1
fi
started=1
trycnt=0
while [[ "$started" -ne 0 && "$trycnt" -lt 10 ]]; do
    logInfo "Try count = $trycnt"
    execute_kubectl "kubectl get deployment ${APP_API_NAME} -n ${K8S_NAMESPACE}" "non-fatal"
    execute_kubectl "kubectl rollout status deployment/${APP_API_NAME} -n ${K8S_NAMESPACE}" "non-fatal"
    if grep -q "successfully rolled out" ./cmd.log; then
        execute_kubectl "kubectl get pods -l=app=${APP_API_NAME} -n ${K8S_NAMESPACE}" "non-fatal"
        cp ./cmd.log ./pods.log
        sleep 15s
        while read p; do
            if [[ "$p" == *"Running"* ]]; then
                podName=`echo "$p" | awk '{print $1}'`
                execute_kubectl "kubectl describe pod ${podName} -n ${K8S_NAMESPACE}" "non-fatal"
                execute_kubectl "kubectl logs ${podName} -n ${K8S_NAMESPACE}" "non-fatal"
                if [ "${SHOW_POD_LOG}" == "true" ]; then
                    cat ./cmd.log
                fi
            fi
        done <./pods.log
        started=0
        break
    fi
    ((trycnt+=1))
    sleep 30s
done
if [[ "$started" -ne 0 ]]; then
    logError "Rollout failed to complete in 5 minutes"
    exit 1
fi
echo ""
exit 0
