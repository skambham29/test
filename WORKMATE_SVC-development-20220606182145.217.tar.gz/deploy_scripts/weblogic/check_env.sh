#!/bin/bash
################################################################################
#                                                                              #
# This script will attempt to check if the server environment is configured    #
#  correctly for the deployment to run.  Standard checks are:                  #
#   location of required commands                                              #
#   environment variables are defined                                          #
#                                                                              #
# Arguments:                                                                   #
#  $1 - The environment to deploy to                                           #
#  $2 - Password for the administrative account (weblogic)                     #
#  $3 - The panda directory                                                    #
#                                                                              #
# Author: Ken Rumer - 9/21/2010                                                #
#                                                                              #
################################################################################
echo "-------------------"
echo "Running check_env.sh"
. ~/.profile

if [ $# -lt 3 ]; then
    echo "usage: $0 environment password panda_dir"
    exit 1
fi

ENVIRONMENT=${1}
PASSWD="${2}"
PANDA_DIR="${3}"
DEPLOY_PROPERTIES="${4}"
cd ${PANDA_DIR}

for DEPLOY_PROPERTIES_FILE in $(echo $DEPLOY_PROPERTIES | sed "s/,/ /g"); do
    echo "INFO: Apply deploy properties file: ${DEPLOY_PROPERTIES_FILE}"
    . ${DEPLOY_PROPERTIES_FILE}
done

#DOMAIN_NAME comes from $DEPLOY_PROPERTIES, need to get the standard variables from the domain home
if [ -z ${DOMAIN_NAME} ]; then
    echo "DOMAIN_NAME variable is missing from ${DEPLOY_PROPERTIES}, deploy cannot continue..."
    exit 1
fi

eval ADMIN_SERVER_NAMES=\${${DOMAIN_NAME}_ADMIN_SERVER_NAMES}
for admin_server_name in ${ADMIN_SERVER_NAMES}; do
    eval ADMIN_HOME=\${${DOMAIN_NAME}_${admin_server_name}_ADMIN_HOME}
    if [ ! -f ${ADMIN_HOME}/.wls_${DOMAIN_NAME}_${admin_server_name}_admin ]; then
    	echo "Admin definition file for \"${admin_server_name}\" of domain \"${DOMAIN_NAME}\" not found"
		continue
    fi
	. ${ADMIN_HOME}/.wls_${DOMAIN_NAME}_${admin_server_name}_admin
done

for file in ${REQUIRED_FILES}; do
    if [ ! -f ${file} ]; then
		echo "$0: File not found \"${file}\"..."
		exit 1
    fi
done

for variable in ${REQUIRED_ENV_VARIABLES}; do
    eval test_var=\$${variable}
    if [ -z "$test_var" ]; then
		echo "$variable not found in"
		echo "`env`"
		exit 1
	else
		echo "$variable found = '$test_var'"
    fi
done

for cmd in ${REQUIRED_COMMANDS}; do
    if ! which $cmd 1>/dev/null 2>&1; then
		echo "$cmd not found in $PATH"
		exit 1
    fi
done

if [[ "`java -version 2>&1 | head -n 1 | awk '{print $3}' | tr '\"' '\0'`" != ${REQ_JAVA_VERSION}* ]]; then
    echo "java version is not ${REQ_JAVA_VERSION}"
    exit 1
fi

if  [ ${OSTYPE} == 'linux-gnu' ]; then
    if ! /app/Middleware/wl12*/bin/status -domains=\"${DOMAIN_NAME}\"\ 1>/dev/null 2>&1; then
		echo "admin server for ${DOMAIN_NAME} is not running..."
		exit 1
    fi
else
    if ! /app/bea10/bin/status -domains=\"${DOMAIN_NAME}\"\ 1>/dev/null 2>&1; then
		echo "admin server for ${DOMAIN_NAME} is not running..."
		exit 1
    fi
fi
