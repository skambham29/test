#!/bin/bash
################################################################################
#                                                                              #
# This script is used to deploy an enterprise service.  There are reusable     #
#  functions in the deploy_scripts/deploy_functions file which is sourced      #
#  by this script.  Generally, the steps for deployment are undeploy existing  #
#  code, deploy new code and bounce the application servers.  This can vary    #
#  by environment.                                                             #
#                                                                              #
# Arguments:                                                                   #
#  $1 - The environment to deploy to                                           #
#  $2 - Password for the administrative account (weblogic)                     #
#  $3 - The panda directory                                                    #
#                                                                              #
# Author: Ken Rumer - 9/21/2010                                                #
#                                                                              #
################################################################################
echo "-----------------"
echo "Running deploy.sh"
. ~/.profile

if [ $# -lt 3 ]; then
    echo "usage: $0 environment password panda_dir"
    exit 1
fi

ENVIRONMENT=$1
PASSWD=$2
PANDA_DIR=$3
DEPLOY_PROPERTIES="${4}"

for DEPLOY_PROPERTIES_FILE in $(echo $DEPLOY_PROPERTIES | sed "s/,/ /g"); do
    echo "INFO: Apply deploy properties file: ${DEPLOY_PROPERTIES_FILE}"
    . ${DEPLOY_PROPERTIES_FILE}
done

FUNCTION_SCRIPT="${PANDA_DIR}/deploy_scripts/deploy_functions.sh"
. ${FUNCTION_SCRIPT}
DIST_DIR="${PANDA_DIR}/dist"

eval ADMIN_SERVER_NAMES=\${${DOMAIN_NAME}_ADMIN_SERVER_NAMES}
for admin_server_name in ${ADMIN_SERVER_NAMES}; do
    eval ADMIN_HOME=\${${DOMAIN_NAME}_${admin_server_name}_ADMIN_HOME}
    . ${ADMIN_HOME}/.wls_${DOMAIN_NAME}_${admin_server_name}_admin
done

. ${DOMAIN_HOME}/.wls_${DOMAIN_NAME}_${DOMAIN_NAME}admin_server*

echo "Deployment type is $DEPLOY_TYPE..."
echo "Currently Running Apps are..."
${JAVA_HOME}/bin/java -cp $WLST_CP weblogic.Deployer -adminurl ${ADMIN_SERVER}:${ADMIN_PORT} -user ${WLS_USER_NAME} -password ${PASSWD} -listapps

if [ -n "${EXTRACT_JAR_SPECS}" ]; then
    echo "Extracting jar files..."
    for extract_jar_spec in ${EXTRACT_JAR_SPECS}; do
		jar_file=`echo ${extract_jar_spec} | cut -f1 -d":"`
		extract_dir=`echo ${extract_jar_spec} | cut -f2 -d":"`
		echo "extract_jar ${PANDA_DIR}/${jar_file} ${extract_dir}"
		extract_jar ${PANDA_DIR} ${PANDA_DIR}/${jar_file} ${extract_dir}
    done
fi

if [ -n "${FILTER_SPECS}" ]; then
    echo "Running ant tasks..."
    for filter_spec in ${FILTER_SPECS}; do
		build_file=`echo ${filter_spec} | cut -f1 -d":"`
		target=`echo ${filter_spec} | cut -f2 -d":"`
		echo "build_file is $build_file..."
		echo "target is $target..."  
		filter_files ${ENVIRONMENT} ${PASSWD} ${PANDA_DIR} ${build_file} ${target}
    done
fi

if [ -n "${CREATE_JAR_SPECS}" ]; then
    echo "Creating jar files..."
    for create_jar_spec in ${CREATE_JAR_SPECS}; do
		jar_file=`echo ${create_jar_spec} | cut -f1 -d":"`
		create_dir=`echo ${create_jar_spec} | cut -f2 -d":"`
		create_jar ${PANDA_DIR} ${jar_file} ${create_dir}
    done
fi
  
if [ -n "${UPDATE_EAR_SPECS}" ]; then
    echo "Updating ear files..."
    for update_ear_spec in ${UPDATE_EAR_SPECS}; do
		ear_file=`echo ${update_ear_spec} | cut -f1 -d":"`
		jar_file=`echo ${update_ear_spec} | cut -f2 -d":"`
		update_ear ${PANDA_DIR} ${ear_file} ${jar_file}
    done
fi

if [ -n "${LOCAL_COPY_FILE_SPECS}" ]; then
    echo "Copying files to the local system..."
    for local_copy_file_spec in ${LOCAL_COPY_FILE_SPECS}; do
		source_path=`echo ${local_copy_file_spec} | cut -f1 -d":"`
		dest_path=`echo ${local_copy_file_spec} | cut -f2 -d":"`
		build_file=`echo ${local_copy_file_spec} | cut -f3 -d":"`
		target=`echo ${local_copy_file_spec} | cut -f4 -d":"`
		copy_local_files ${ENVIRONMENT} ${PASSWD} ${PANDA_DIR} "${source_path}" ${dest_path} ${build_file} ${target}
    done
fi

case ${DEPLOY_TYPE} in
	no_bounce)
    	echo "Attempting to deploy ${SERVICE_MODULES}..."

    	#for host in ${NODE_SERVERS}; do
        #	copy_remote_files ${PANDA_DIR} ${host}
    	#done

    	for service_module in ${SERVICE_MODULES}; do
        	stop_module ${ADMIN_SERVER}:${ADMIN_PORT} ${WLS_USER_NAME} ${PASSWD} ${service_module}
        	echo "Done stopping ${service_module}..."
    	done
 
    	for service_module in ${SERVICE_MODULES}; do
        	undeploy_module ${ADMIN_SERVER}:${ADMIN_PORT} ${WLS_USER_NAME} ${PASSWD} ${service_module}
        	echo "Done undeploying ${service_module}..."
    	done

    	for service_module in ${SERVICE_MODULES}; do
        	deploy_module ${ADMIN_SERVER}:${ADMIN_PORT} ${WLS_USER_NAME} ${PASSWD} ${DIST_DIR} ${DOMAIN_HOME} ${service_module} ${CLUSTER_NAME}
        	echo "Done deploying ${service_module} to ${WLS_TARGETS}..."
    	done 

    	for service_module in ${SERVICE_MODULES}; do
        	start_module ${ADMIN_SERVER}:${ADMIN_PORT} ${WLS_USER_NAME} ${PASSWD} ${service_module}
        	echo "Done starting ${service_module}..."
    	done
    	;;
    *)
		echo "Attempting to deploy ${SERVICE_MODULES}..."
    	for service_module in ${SERVICE_MODULES}; do
			module=`echo $service_module | cut -d":" -f1`
        	undeploy_module ${ADMIN_SERVER}:${ADMIN_PORT} ${WLS_USER_NAME} ${PASSWD} ${module}
        	echo "Done undepolying ${module}..."
    	done

    	for service_module in ${SERVICE_MODULES}; do
        	module=`echo $service_module | cut -d":" -f1`
			# cluster=`echo $service_module | cut -d":" -f2`
        	if [ -z "$cluster" ]; then
        		cluster=$CLUSTER_NAME
        	fi
        	deploy_module ${ADMIN_SERVER}:${ADMIN_PORT} ${WLS_USER_NAME} ${PASSWD} ${DIST_DIR} ${DOMAIN_HOME} ${module} ${cluster}
        	echo "Done deploying ${service_module} to ${WLS_TARGETS}..."
        
        	if [ "$module" == "quartz" ]; then
            	change_deployorder ${ADMIN_SERVER}:${ADMIN_PORT} ${WLS_USER_NAME} ${PASSWD} ${module} ${DEPLOYMENT_ORDER}
            	echo "Done changing deployment order for ${module} to ${DEPLOYMENT_ORDER}..."
        	fi
    	done

		echo "Bounce the domain servers..."
		${DOMAIN_HOME}/domainctl rolling
		if [[ $? != 0 ]]; then
			echo "Error bouncing the servers"
			exit 1
		fi
    	;;
esac

exit 0
