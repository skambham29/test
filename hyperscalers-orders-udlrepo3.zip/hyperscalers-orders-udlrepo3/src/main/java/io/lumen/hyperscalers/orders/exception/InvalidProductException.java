package io.lumen.hyperscalers.orders.exception;

import java.util.stream.Collectors;

import io.lumen.hyperscalers.orders.constants.Constants;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InvalidProductException extends RuntimeException {
	
	public InvalidProductException (String invalidProducts) {
		super ("Invalid Service(s) passed: " + invalidProducts + ". Valid values are: " + Constants.VALID_PRODUCTS.stream().collect(Collectors.joining(",")));
	}


}
