package io.lumen.hyperscalers.orders.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class Milestone {
	
	@Schema (example = "PLAN", description = "Milestone name: PLAN/DESIGN/BUILD/ACTIVATE")
	private String name;
	@Schema (example = "COMPLETE_REFLECTION", description = "Current status of milestone")
	private String status;
	@Schema (example = "2020-12-27", description = "Milestone start date")
	private String startDate;
	@Schema (example = "2020-12-30", description = "Completion date for milestone")
	private String completedDate;
	@Schema (example = "2020-12-30", description = "Date of last update on this milestone")
	private String lastUpdatedDate;

}
