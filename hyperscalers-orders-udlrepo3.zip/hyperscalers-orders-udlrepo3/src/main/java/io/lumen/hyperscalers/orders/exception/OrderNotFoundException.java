package io.lumen.hyperscalers.orders.exception;

public class OrderNotFoundException extends RuntimeException {

	public OrderNotFoundException (String custOrderNbr) {
		super ("No data found for order: " + custOrderNbr);
	}
	
}
