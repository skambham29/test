package io.lumen.hyperscalers.orders.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.config.SchemaAction;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

/**
 *
 * @author Enes
 */
//@Configuration
//@EnableCassandraRepositories
public class CassandraConfigTest extends AbstractCassandraConfiguration {

  // some other configuration
  private static final Logger log = LogManager.getLogger(CassandraConfigTest.class);
  @Value("${spring.data.cassandra.keyspace-name}")
  private String keyspace;

  @Override
  protected List<String> getStartupScripts() {
    final String script =
        "CREATE KEYSPACE IF NOT EXISTS "
            + keyspace
            + " WITH durable_writes = true"
            + " AND replication = {'class' : 'SimpleStrategy', 'replication_factor' : 1};";
    return Arrays.asList(script);
  }

@Override
protected String getKeyspaceName() {
	// TODO Auto-generated method stub
	log.info("keyspace"+keyspace);
	return keyspace;
}
}