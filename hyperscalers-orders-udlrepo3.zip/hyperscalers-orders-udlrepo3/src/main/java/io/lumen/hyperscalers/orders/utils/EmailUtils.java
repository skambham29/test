package io.lumen.hyperscalers.orders.utils;

import org.apache.commons.lang3.exception.ExceptionUtils;


public interface EmailUtils {
	
	String API_FAILED_SUB = " [hyperscalers-orders] API FAILED ";
	String API_FAILED_MSG = "Hyperscalers orders api endpoint failed.";
	
	String EXCEPTION_HEADER = "<u><b>Exception Details:</b></u><br/>";
	public static String getExceptionEmailBody(Throwable throwable) {
		StringBuilder msgBuilder = new StringBuilder();
		msgBuilder.append("<b>")
				  .append(API_FAILED_MSG)
				  .append("</b><br/>")
				  .append(EXCEPTION_HEADER)
				  .append(ExceptionUtils.getStackTrace(throwable));
		
		return msgBuilder.toString();
	}
	
	public static String getExceptionEmailSubject(String env) {
		StringBuilder msgBuilder = new StringBuilder();
		msgBuilder.append(env)
				  .append(API_FAILED_SUB);
		
		return msgBuilder.toString();
	}

}
