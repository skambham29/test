package io.lumen.hyperscalers.orders.model;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@RequestScope
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Consumer {
	
	private String userId;
	private Set<String> custNbrs;
	private String ultCustNbr;
	private String access;

}
