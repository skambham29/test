package io.lumen.hyperscalers.orders.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;

import org.springframework.data.cassandra.config.SchemaAction;
import org.springframework.data.cassandra.core.cql.keyspace.CreateKeyspaceSpecification;
import org.springframework.data.cassandra.core.cql.keyspace.DataCenterReplication;
import org.springframework.data.cassandra.core.cql.keyspace.KeyspaceOption;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;



public class CassandraConfig extends AbstractCassandraConfiguration {

  // some other configuration
private static final Logger log = LogManager.getLogger(CassandraConfig.class);
  @Value("${spring.data.cassandra.keyspace-name}")
  private String keyspace;
  
  @Value("${spring.data.cassandra.contact-points}")
  private String contactPoints;

  @Value("${spring.data.cassandra.port}")
  private int port;

 // @Value("${spring.data.cassandra.basePackages}")
  private String basePackages="io.lumen.hyperscalers.orders";
  private String username="hyperscalers-service-data-dev";
  private String password="UCNKiTMSOkWPJ9bJtU3D5bl3B01llFo3ilJpVECmIORYKoYtGaKsSFlrWOupGHDbUIfuFCYbTpgC15LeJpw3ZA==";

  
  @Override
  protected List<CreateKeyspaceSpecification> getKeyspaceCreations() {
    return Collections.singletonList(CreateKeyspaceSpecification.createKeyspace(keyspace)
                .ifNotExists()
                .with(KeyspaceOption.DURABLE_WRITES, true)
                .withSimpleReplication());
  }

  @Override
  protected List<String> getStartupScripts() {
    return Collections.singletonList("CREATE KEYSPACE IF NOT EXISTS "+keyspace+"WITH REPLICATION = {'class' : 'SimpleStrategy'} WITH default_time_to_live = 600;");
  }
  
  //  @Override
//  protected List<String> getStartupScripts() {
//	  log.info("getStartupScripts ");
//    final String script =
//        "CREATE KEYSPACE weather WITH REPLICATION = {'class' : 'SimpleStrategy'};";
//            
//    List<String> str = new ArrayList<String>();
//    str.add(script);
//    return str;
//  }
//  @Bean
//  public CassandraCqlClusterFactoryBean cluster() {
//      CassandraCqlClusterFactoryBean bean = new CassandraCqlClusterFactoryBean();
//      bean.setKeyspaceCreations(getKeyspaceCreations());
//      bean.setContactPoints(contactPoints);
//      bean.setPort(port);
//      bean.setUsername(username);
//      bean.setPassword(password);
//      return bean;
//  }


//  @Override
//  protected String getContactPoints() {
//	  log.info("contactPoints "+contactPoints);
//    return contactPoints;
//  }

//  @Override
//  protected int getPort() {
//	  log.info("getPort ");
//    return port;
//  }

//  @Override
//  public SchemaAction getSchemaAction() {
//	  log.info("getSchemaAction ");
//    return SchemaAction.CREATE_IF_NOT_EXISTS;
//  }
//
//  @Override
//  public String[] getEntityBasePackages() {
//	  log.info("getEntityBasePackages ");
//    return new String[] {basePackages};
//  }
//  
	@Override
	protected String getKeyspaceName() {
		log.info("keySpace "+keyspace);
		return keyspace;
	}
	
//	public String getUsername() {
//		return username;
//	}
//	
//	public String getPassword() {
//		return password;
//	}
	
//	 @Override
//	  protected List<CreateKeyspaceSpecification> getKeyspaceCreations() {
//		 log.info("getKeyspaceCreations ");
//	    final CreateKeyspaceSpecification specification =
//	        CreateKeyspaceSpecification.createKeyspace(keyspace)
//	        	.ifNotExists()
//	            .with(KeyspaceOption.DURABLE_WRITES, true)
//	            .withNetworkReplication(new DataCenterReplication("West US 2", 3L));
//	           
//	    List<CreateKeyspaceSpecification> str = new ArrayList<CreateKeyspaceSpecification>();
//	    str.add(specification);
//	    return str;
//	   
//	  }
//	 protected List<CreateKeyspaceSpecification> getKeyspaceCreations() {
//	        List<CreateKeyspaceSpecification> createKeyspaceSpecifications = new ArrayList<>();
//	        createKeyspaceSpecifications.add(getKeySpaceSpecification());
//	        return createKeyspaceSpecifications;
//	    }
//
//	    // Below method creates "my_keyspace" if it doesnt exist.
//	    private CreateKeyspaceSpecification getKeySpaceSpecification() {
//	        CreateKeyspaceSpecification pandaCoopKeyspace =CreateKeyspaceSpecification.createKeyspace(keyspace);
//	        DataCenterReplication dcr = DataCenterReplication.of("West US 2", 3L);
//	        
//	        pandaCoopKeyspace.ifNotExists(true).withNetworkReplication(dcr);
//	        return pandaCoopKeyspace;
//	    }
//  @Override
//  protected List<String> getShutdownScripts() {
//    return List.of("DROP KEYSPACE IF EXISTS " + keyspace + ";");
//  }
}


















//import org.springframework.data.cassandra.config.CassandraClusterFactoryBean;
//import org.springframework.data.cassandra.config.CqlSessionFactoryBean;
//import org.springframework.data.cassandra.core.mapping.BasicCassandraMappingContext;
//import org.springframework.data.cassandra.core.mapping.CassandraMappingContext;
//import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

//import io.lumen.hyperscalers.orders.filter.AuthorizationFilter;
//@Configuration
//@EnableCassandraRepositories(basePackages = {"io.lumen.hyperscalers.orders"})

//public class CassandraConfig extends AbstractCassandraConfiguration {
//	private static final Logger log = LogManager.getLogger(CassandraConfig.class);
//
//
//    @Value("${spring.data.cassandra.keyspace-name}")
//    private String keySpace;
//    
//    @Value("${spring.data.cassandra.contact-points}")
//    private String contactPoints;
//    
//    @Value("${spring.data.cassandra.port}")
//    private int port;
//    
//    @Value("${spring.data.cassandra.username} ")
//    private String userName;
//    
//    @Value("${spring.data.cassandra.password}")
//    private String password;
//    
//    @Value("${spring.data.cassandra.local-datacenter}")
//    private String localDataCenter;
//    
//    @Value("${spring.data.cassandra.schema-action}")
//    private String schemaAction;
//    
//	@Override
//	protected String getKeyspaceName() {
//		log.info("keySpace "+keySpace);
//		return keySpace;
//	}
//	
////	@Bean
////    public CassandraClusterFactoryBean cluster() {
////        CassandraClusterFactoryBean cluster = 
////          new CassandraClusterFactoryBean();
////        cluster.setContactPoints(contactPoints);
////        cluster.setPort(port);
////        return cluster;
////    }
////
////    @Bean
////    public CassandraMappingContext cassandraMapping() 
////      throws ClassNotFoundException {
////        return new BasicCassandraMappingContext();
////    }
//	//@Bean
////    @Override
////    public CqlSessionFactoryBean cassandraSession() {
////        CqlSessionFactoryBean cassandraSession = super.cassandraSession();//super session should be called only once
////        cassandraSession.setContactPoints(contactPoints);
////        cassandraSession.setKeyspaceName(keySpace);
////        cassandraSession.setPort(port);
////        cassandraSession.setLocalDatacenter(localDataCenter);
////        cassandraSession.setSchemaAction(getSchemaAction());;
////        cassandraSession.setUsername(userName);
////        cassandraSession.setPassword(password);
////        return cassandraSession;
////
////}
//}
