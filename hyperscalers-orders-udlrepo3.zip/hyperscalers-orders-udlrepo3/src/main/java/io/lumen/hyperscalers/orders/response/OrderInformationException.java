package io.lumen.hyperscalers.orders.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class OrderInformationException {
	
	ExDetail exception;

}
