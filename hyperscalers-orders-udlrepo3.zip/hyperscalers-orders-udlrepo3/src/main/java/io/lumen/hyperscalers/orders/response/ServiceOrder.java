package io.lumen.hyperscalers.orders.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
public class ServiceOrder {
	
	
	@Schema (example = "Wavelength", description = "Type of service: Wavelength , Colo , DIA , Dark Fiber")
	private String serviceType;
	@Schema (example = "100GIG-E LAN", description = "Service or Product description")
	private String description;
	@Schema (example = "2020-12-26", description = "Date when the order was received")
	private String orderReceivedDate;
	@Schema (example = "2020-12-26", description = "Original requested due date")
	private String originalRequestedDueDate;
	@Schema (example = "2021-01-25", description = "Firm order confirmation date")
	private String firmOrderConfirmationDate;
	@Schema (example = "2021-01-29", description = "Bill start date")
	private String actualDeliveryDate;
	@Schema (example = "TRIM.20200917.02", description = "Purchase Order Number. For Microsoft , Trim Order Number")
	private String customerOrderNumber;
	@Schema (example = "440916087", description = "Service Order number")
	private String serviceId;
	@Schema (example = "Wavelength", description = "Type of service: Wavelength , Colo , DIA , Dark Fiber")
	private String service;
	@Schema (example = "2021-01-25", description = "Current Customer Commit Date (includes Revised)")
	private String currentCustomerCommitDate;
	@Schema (example = "8201 DORSEY RUN RD, ANNAPOLIS JUNCTION, MARYLAND, 89023", description = "A end address")
	private String ultimateA;
	@Schema (example = "MMR 1.4.3, cabinet 01.01.02.RMU 38. PORTS 91/92", description = "CFA for A end")
	private String cfaEndA;
	@Schema (example = "7471 BEAR WALLOW RD, WARRENTON, VIRGINIA, 40883", description = "Z end address")
	private String ultimateZ;
	@Schema (example = "MMRNORTH, RR 001.002.008.21, RMU 21, JK 6 PORTS 11&12", description = "CFA for Z end")
	private String cfaEndZ;
	@Schema (example = "2021-01-25", description = "Bill stop date/disconnect date")
	private String serviceEndDate;
	@Schema (example = "Lumen", description = "Static value: Lumen")
	private String vendorName;
	@Schema (example = "2020-12-26", description = "Date the contract was signed")
	private String contractSignedDate;
	@JacksonXmlElementWrapper(localName = "circuitIds")
    @JacksonXmlProperty(localName = "circuitId")
	private List<String> circuitIds;
	@Schema (example = "IPVersion:	IPv4	WANIPv4:	4.1.95.184/30	Customer AS Number:		EVPL Hub:", description = "IPConfig data")
	private IpConfig ipConfig;
	@JacksonXmlElementWrapper(localName = "milestones")
    @JacksonXmlProperty(localName = "milestone")
	private List<Milestone> milestones;
	
}
