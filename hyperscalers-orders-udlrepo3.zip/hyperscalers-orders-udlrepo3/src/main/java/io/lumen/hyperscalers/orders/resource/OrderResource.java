package io.lumen.hyperscalers.orders.resource;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import io.lumen.hyperscalers.orders.constants.Constants;
import io.lumen.hyperscalers.orders.exception.InvalidOrderStatusException;
import io.lumen.hyperscalers.orders.exception.InvalidProductException;
import io.lumen.hyperscalers.orders.model.Consumer;
import io.lumen.hyperscalers.orders.response.Order;
import io.lumen.hyperscalers.orders.response.OrderInformationException;
import io.lumen.hyperscalers.orders.response.OrderInformationResponse;
import io.lumen.hyperscalers.orders.service.OrderInformationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class OrderResource {
	private static final Logger logger = LogManager.getLogger(OrderResource.class);

	
	@Autowired
	OrderInformationService orderInformationService;
	@Autowired
    Consumer consumer;
	
    @Value("${spring.data.cassandra.username} ")
    private String userName;
    
    @Value("${spring.data.cassandra.password}")
    private String password;
	
	Optional<List<String>> custnbrlst =null;

	@Operation (
			summary = "Fetch information for orders based on query paramters passed",
			description = "Service will return ALL orders if no parameters are provided. If \\\"customer order number\\\" parameter is provided then other parameters will be"
					+ " ignored. The parameters \"service\" & \"status\" accept a list of values specified below. ",
			parameters = {
					@Parameter (in=ParameterIn.QUERY, 
							    name = "service", 
							    example = "wavelength",
							    description = "Get orders for a specific service(s) only. Valid values are: wavelength, dia, darkfiber, colo",
							    required = false),
					@Parameter (in=ParameterIn.QUERY, 
					            name = "customerordernumber", 
					            example = "TRIM.08738734.02",
					            description = "Get orders for a specific customer order number only",
					            required = false),
					@Parameter (in=ParameterIn.QUERY, 
		            			name = "status", 
		            			example = "in progress",
		            			description = "Get orders that are in a specific status(s). Valid values are: in progress, pending, completed, cancelled",
		            			required = false)					
			}
	)
	@ApiResponses (value = {
			@ApiResponse (responseCode = "200",description = "Successful operation",
					content = { @Content (schema = @Schema(implementation = OrderInformationResponse.class)) }),
			@ApiResponse (responseCode = "404",description = "No orders found for customer order number provided",
					content = { @Content (schema = @Schema(implementation = OrderInformationException.class)) })
	})
	@GetMapping (value = "/orders", produces = { "application/xml", "application/json" })
	public ResponseEntity<OrderInformationResponse> getAllInProgressOrders(
		@RequestParam (name = "service", required = false) Optional<List<String>> services,
		@RequestParam (name = "customerordernumber", required = false) Optional<String> customerOrderNumber,
		@RequestParam(value="status", required=false) Optional<List<String>> statuses) {
		
		if(consumer==null)
		{
			custnbrlst = Optional.of(new ArrayList<String>());
			custnbrlst.get().add(Constants.CUSTNBR);
		}
		else
		{	
			custnbrlst = Optional.of(consumer.getCustNbrs().stream()
                    .map(Object::toString)
                    .collect(Collectors.toList()));
		}
		validateParams(services, customerOrderNumber, statuses);
		List<Order> orders = orderInformationService.getOrderInformation(services, customerOrderNumber, statuses, custnbrlst.get());
		OrderInformationResponse response = new OrderInformationResponse (orders);
		
		return ResponseEntity.ok()
				.body(response);
		
	}
	
	public void validateParams(Optional <List<String>> products, Optional<String> purchaseOrderNbr, Optional <List<String>> statuses ) {
		
		if (!purchaseOrderNbr.isPresent()) {
			//Validate products passed
			if (products.isPresent() && products.get().size() >= 1) {
				List<String> validProducts = products.get().stream()
					.filter(p -> Constants.VALID_PRODUCTS.contains(p.toLowerCase()))
					.collect(Collectors.toList());
				if (products.get().size() != validProducts.size()) {
					String invalidProducts = products.get().stream()
							.filter(p -> !validProducts.contains(p.toLowerCase()))
							.collect(Collectors.joining(","));
					throw new InvalidProductException(invalidProducts);
				}
			}
			
			//Validate statuses passed
			if (statuses.isPresent() && statuses.get().size() >= 1) {
				List<String> validStatuses = statuses.get().stream()
					.filter(s -> Constants.VALID_STATUSES.contains(s.toLowerCase()))
					.collect(Collectors.toList());
				if (statuses.get().size() != validStatuses.size()) {
					String invalidStatuses = statuses.get().stream()
							.filter(s -> !validStatuses.contains(s.toLowerCase()))
							.collect(Collectors.joining(","));
					throw new InvalidOrderStatusException(invalidStatuses);
				}
			}
		}
		
	}

	

}
