package io.lumen.hyperscalers.orders.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ExDetail {
	
	@Schema (example = "404", description = "Http Status")
	private String httpStatusCode;
	@Schema (example = "404501", description = "Code specific to a type of exception")
	private String code;
	@Schema (example = "NOT_FOUND", description = "Http Status message")
	private String message;
	@Schema (example = "No data found for purchase order: TRIM.20200990.x2", description = "Detailed information")
	private String detail;

}
