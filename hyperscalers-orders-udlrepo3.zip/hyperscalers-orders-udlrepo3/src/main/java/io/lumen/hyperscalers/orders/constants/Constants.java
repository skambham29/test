package io.lumen.hyperscalers.orders.constants;


import java.util.Set;

import com.datastax.oss.driver.shaded.guava.common.collect.Sets;

public class Constants {
	
	private Constants() {
	    throw new IllegalStateException("Utility class");
	  }
	
	public static final String LUMEN = "Lumen";
	
	public static final Set<String> VALID_STATUSES = Sets.newHashSet("in progress", "pending", "completed", "cancelled");
	public static final Set<String> VALID_PRODUCTS = Sets.newHashSet("wavelength","dia","colo","darkfiber");
	
	public static final String ULTIMATE_CUST_NBR = "1-AEW-2248-UC";
	
	public static final String START_PARENTHESES = "(";
	public static final String END_PARENTHESES = ")";
	public static final String AND = " AND ";
	public static final String OR = " OR ";
	
	public static final String QUERY_BY_CUSTNBR = "custNbr:";
	public static final String QUERY_BY_CUSTPON = "custPon:";
	public static final String QUERY_BY_ORDERSTATUS = "orderStatus:";
	public static final String QUERY_BY_PRODUCTNAME = "productName:";
	public static final String QUERY_RED_NW = "sourceSystem:(\"SWIFT\" OR \"PIPELINE\" OR \"SIEBEL\" OR \"CPO\")";
	
	public static final String UDL = "UDL";
	
	public static final int CDW_COP_FETCH_SIZE = 40;
	public static final int DATA = 100;
	public static final String CUSTNBR = "4413";
	public static final String ORDERS_API_FAILURE_MESSAGE = "Hyperscalar orders api execution failed.";
	public static final String ORDERS_API_FAILURE_EMAIL_SUBJECT_MIDDLE = " | hyperscalers-orders-api | ORDERS API EXECUTION FAILED | Failed Api - ";

	
}
