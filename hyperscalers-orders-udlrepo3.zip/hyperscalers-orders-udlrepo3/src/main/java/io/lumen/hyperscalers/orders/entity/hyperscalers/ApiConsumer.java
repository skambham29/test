package io.lumen.hyperscalers.orders.entity.hyperscalers;

import java.util.Set;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Table(value = "api_consumer")
@AllArgsConstructor
@NoArgsConstructor
public class ApiConsumer {
	
	@PrimaryKey
	private String id;
	@Column (value = "api_consumer_info")
	private String consumerInfo;
	@Column (value = "cust_nbr")
	private Set<String> custNbr;
	@Column (value = "ult_cust_nbr")
	private String ultCustNbr;
	@Column (value = "access")
	private String access;

}
