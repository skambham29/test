package io.lumen.hyperscalers.orders.filter;

import java.io.IOException;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Optional;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.filter.OncePerRequestFilter;



import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.Jwts;

import io.lumen.hyperscalers.orders.entity.hyperscalers.ApiConsumer;
import io.lumen.hyperscalers.orders.exception.UnAuthorizedException;
import io.lumen.hyperscalers.orders.model.Consumer;
import io.lumen.hyperscalers.orders.repository.hyperscalers.ApiConsumerRepository;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthorizationFilter extends OncePerRequestFilter {
	
	static final String KEYFACTORY = "RSA";
	static final String JWT_TYPE = "JWT";
	static final String JWT_ALGORITHM = "RS256";

	@Value("${apigee.jwt.claim.iss}")
	private String iss;
	
	@Value("${apigee.jwt.claim.sub}")
	private String sub;

	@Value("${apigee.jwt.pubkey}")
	private String publickey;
	
	@Autowired
	Consumer consumer;

	
	@Autowired
	ApiConsumerRepository apiConsumerRepository;

	

	private static final Logger log = LogManager.getLogger(AuthorizationFilter.class);
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		

		try {
    		if(request != null) {
    			
    			
	    		String header = request.getHeader("Authorization");
	    	
	    		if (header == null || !header.startsWith("Bearer ")) {
	    			throw new UnAuthorizedException("Not Authorized: No JWT token found in request headers");
	    		}

	    		String jwtToken = header.substring(7);

	    		byte[] publicBytes = Base64.getDecoder().decode(publickey.getBytes());
	    		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
	    		KeyFactory keyFactory = KeyFactory.getInstance(KEYFACTORY);
	    		PublicKey pubKey = keyFactory.generatePublic(keySpec);

	    		@SuppressWarnings("rawtypes")
	    		final JwsHeader jwsHeader = Jwts.parser().setSigningKey(pubKey).parseClaimsJws(jwtToken).getHeader();
	    		String jwtType = jwsHeader.getType();
	    		String jwtAlgorithm = jwsHeader.getAlgorithm();
	    		if (!((jwtType.equals(JWT_TYPE)) && (jwtAlgorithm.equals(JWT_ALGORITHM)))) {
	    			throw new UnAuthorizedException("Invalid JWT Type or Algorithm");
	    		}

	    		final Claims claims = Jwts.parser().setSigningKey(pubKey).parseClaimsJws(jwtToken).getBody();

	    		String issuer = claims.getIssuer();
	    		String subject = claims.getSubject();
	    		log.info("issuer in JWT: " + issuer);
	    		log.info("subject in JWT: " + subject);
	    		String userId = claims.get("userid", String.class);
	    		log.info("userid in JWT: " + userId);
	    		if (!((issuer.equals(iss)) && (subject.startsWith(sub)))) {
	    			throw new UnAuthorizedException("Invalid JWT Issuer or Subject");
	    		} else {
	    			log.info("inside else");
	    			consumer.setUserId(userId);
	    			log.info("inside else"+consumer.getUserId());
	    			Optional<ApiConsumer> apiConsumer = apiConsumerRepository.findById(consumer.getUserId());
	    			if (apiConsumer.isPresent()) {
	    				ApiConsumer ac = apiConsumer.get();
	    					log.info("ac.getCustNbr() ac.getUltCustNbr() ac.getAccess() "
	    						+ac.getCustNbr() +ac.getUltCustNbr() +ac.getAccess());
	    				consumer.setCustNbrs(ac.getCustNbr());
	    				consumer.setUltCustNbr(ac.getUltCustNbr());
	    				consumer.setAccess(ac.getAccess());

	    			} else {
	    				throw new UnAuthorizedException("Unauthorized");
	    			}
	    		}
    		}
    		filterChain.doFilter(request, response);
	    		
		} catch (Exception e) {
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
				response.getOutputStream().println(e.getMessage());
			
		}
	}
	
}