package io.lumen.hyperscalers.orders.config;

import javax.servlet.Filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.lumen.hyperscalers.orders.filter.AuthorizationFilter;

@Configuration
public class AuthorizationConfig {
	
	@Bean
	public FilterRegistrationBean authorizationFilterRegistration() {
		FilterRegistrationBean registration = new FilterRegistrationBean();
		registration.setFilter(authorizationFilter());
		registration.setName("authorizationFilter");
		registration.addUrlPatterns("/orders/");
		registration.addUrlPatterns("/orders");
		return registration;
	}

	@Bean
	public Filter authorizationFilter() {
		return new AuthorizationFilter();
	}

}
