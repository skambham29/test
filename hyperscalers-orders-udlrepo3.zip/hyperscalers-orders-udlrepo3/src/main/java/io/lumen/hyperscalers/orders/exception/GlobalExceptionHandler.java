package io.lumen.hyperscalers.orders.exception;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import io.lumen.hyperscalers.orders.response.ExDetail;
import io.lumen.hyperscalers.orders.response.OrderInformationException;
import io.lumen.hyperscalers.orders.service.EmailAlertService;
import io.lumen.hyperscalers.orders.utils.EmailUtils;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler {
	
	@Autowired
	EmailAlertService emailAlertService;
	private static final Logger logger = LogManager.getLogger(GlobalExceptionHandler.class);
	
	@Value("${api.execution.env}")
	String env;
	
	@Value("${hyper.mail.enable}")
	Boolean enableEmail;

	
	@ExceptionHandler
	public ResponseEntity<OrderInformationException> handleInvalidProductException (InvalidProductException e) {
		ExDetail exceptionDetail = new ExDetail(HttpStatus.BAD_REQUEST.toString().substring(0,3), "400501", HttpStatus.BAD_REQUEST.toString().substring(4), e.getMessage());
		
		return new ResponseEntity<>(new OrderInformationException(exceptionDetail), HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler
	public ResponseEntity<OrderInformationException> handleInvalidStatusException (InvalidOrderStatusException e) {
		ExDetail exceptionDetail = new ExDetail(HttpStatus.BAD_REQUEST.toString().substring(0,3), "4005005", HttpStatus.BAD_REQUEST.toString().substring(4), e.getMessage());
		return new ResponseEntity<>(new OrderInformationException(exceptionDetail), HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler
	public ResponseEntity<OrderInformationException> handleOrderNotFoundException (OrderNotFoundException e) {
		ExDetail exceptionDetail = new ExDetail(HttpStatus.NOT_FOUND.toString().substring(0,3), "404501", HttpStatus.NOT_FOUND.toString().substring(4), e.getMessage());
		
		return new ResponseEntity<>(new OrderInformationException(exceptionDetail), HttpStatus.NOT_FOUND);
	}
	
	
	
	@ExceptionHandler
	public ResponseEntity<OrderInformationException> handleException (Exception e) {
		ExDetail exceptionDetail = new ExDetail(HttpStatus.INTERNAL_SERVER_ERROR.toString().substring(0,3), 
				"500999", HttpStatus.INTERNAL_SERVER_ERROR.toString().substring(4), "Please try after sometime");
		if (enableEmail) {
			emailAlertService.sendEmailNotification(EmailUtils.getExceptionEmailBody(e),
					EmailUtils.getExceptionEmailSubject(env));
		}
		logger.error("ExceptionUtils.getStackTrace "+ExceptionUtils.getStackTrace(e));
		return new ResponseEntity<>(new OrderInformationException(exceptionDetail), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}
