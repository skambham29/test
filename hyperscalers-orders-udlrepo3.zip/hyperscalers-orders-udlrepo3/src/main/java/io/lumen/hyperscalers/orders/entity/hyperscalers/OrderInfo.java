package io.lumen.hyperscalers.orders.entity.hyperscalers;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@EqualsAndHashCode
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(value="order_info")
public class OrderInfo {

	@PrimaryKey
	private OrderInfoKey orderInfoKey;
	@Column(value = "service_type")
	private String serviceType;
	@Column(value = "description")
	private String description;
	@Column(value = "order_received_dt")
	private LocalDate orderReceivedDt;
	@Column(value = "orig_requested_due_dt")
	private LocalDate origRequestedDueDt;
	@Column(value = "firm_order_completion_dt")
	private LocalDate firmOrderCompletionDt;
	@Column(value = "actual_delivery_dt")
	private LocalDate actualDeliveryDt;
	@Column(value = "cust_order_nbr")
	private String custOrderNbr;
	@Column(value = "service")
	private String service;
	@Column(value = "curr_cust_commit_dt")
	private LocalDate currCustCommitDt;
	@Column(value = "ultimate_a")
	private String ultimateA;
	@Column(value = "cfa_end_a")
	private String cfaEndA; 
	@Column(value = "ultimate_z")
	private String ultimateZ;
	@Column(value = "cfa_end_z")
	private String cfaEndZ;
	@Column(value = "service_end_dt")
	private LocalDate serviceEndDt;
	@Column(value = "vendor_name")
	private String vendorName;
	@Column(value = "contract_sign_dt")
	private LocalDate contractSignDt;
	@Column(value = "circuit_id")
	private List<String> circuitId;
	@Column(value = "ipconfig_ip_version")
	private String ipconfigIpVersion;
	@Column(value = "ipconfig_wanipv4")
	private String ipconfigWanipv4;
	@Column(value = "ipconfig_lanipv4")
	private String ipconfigLanipv4;
	@Column(value = "ipconfig_wanipv6")
	private String ipconfigWanipv6;
	@Column(value = "ipconfig_lanipv6")
	private String ipconfigLanipv6;
	@Column(value = "ipconfig_customer_vlanid")
	private String ipconfigCustomerVlanid;
	@Column(value = "ipconfig_export_policy")
	private String ipconfigExportPolicy;
	@Column(value = "ipconfig_static_route")
	private String ipconfigStaticRoute;
	@Column(value = "ipconfig_maintainer")
	private String ipconfigMaintainer;
	@Column(value = "ipconfig_routing_instance")
	private String ipconfigRoutingInstance;
	@Column(value = "ipconfig_as_number")
	private String ipconfigAsNumber;
	@Column(value = "ipconfig_local_as_number")
	private String ipconfigLocalAsNumber;
	@Column(value = "milestone_1_name")
	private String milestone1Name;
	@Column(value = "milestone_1_status")
	private String milestone1Status;
	@Column(value = "milestone_1_start_dt")
	private LocalDate milestone1StartDt;
	@Column(value = "milestone_1_completed_dt")
	private LocalDate milestone1CompletedDt;
	@Column(value = "milestone_1_last_updated_dt")
	private LocalDate milestone1LastUpdatedDt;
	@Column(value = "milestone_2_name")
	private String milestone2Name;
	@Column(value = "milestone_2_status")
	private String milestone2Status;
	@Column(value = "milestone_2_start_dt")
	private LocalDate milestone2StartDt;
	@Column(value = "milestone_2_completed_dt")
	private LocalDate milestone2CompletedDt;
	@Column(value = "milestone_2_last_updated_dt")
	private LocalDate milestone2LastUpdatedDt;
	@Column(value = "milestone_3_name")
	private String milestone3Name;
	@Column(value = "milestone_3_status")
	private String milestone3Status;
	@Column(value = "milestone_3_start_dt")
	private LocalDate milestone3StartDt;
	@Column(value = "milestone_3_completed_dt")
	private LocalDate milestone3CompletedDt;
	@Column(value = "milestone_3_last_updated_dt")
	private LocalDate milestone3LastUpdatedDt;
	@Column(value = "milestone_4_name")
	private String milestone4Name;
	@Column(value = "milestone_4_status")
	private String milestone4Status;
	@Column(value = "milestone_4_start_dt")
	private LocalDate milestone4StartDt;
	@Column(value = "milestone_4_completed_dt")
	private LocalDate milestone4CompletedDt;
	@Column(value = "milestone_4_last_updated_dt")
	private LocalDate milestone4LastUpdatedDt;
	@Column(value = "status")
	private String orderStatus;
	@Column(value = "cust_nbr")
	private String custnbr;
	@Column(value = "service_name")
	private String serviceName;	
	@Column(value = "service_name_normalized")
	private String serviceNameNormalized;	
	
}

