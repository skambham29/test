package io.lumen.hyperscalers.orders.exception;

import java.util.stream.Collectors;

import io.lumen.hyperscalers.orders.constants.Constants;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InvalidOrderStatusException extends RuntimeException{
	
	public InvalidOrderStatusException (String invalidStatuses) {
		super("Invalid Status(s) passed: " + invalidStatuses + ". Valid values are: " + Constants.VALID_STATUSES.stream().collect(Collectors.joining(",")));
	}

}
