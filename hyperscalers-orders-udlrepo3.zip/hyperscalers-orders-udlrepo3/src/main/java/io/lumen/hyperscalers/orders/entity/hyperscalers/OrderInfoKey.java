package io.lumen.hyperscalers.orders.entity.hyperscalers;

import java.io.Serializable;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyClass;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@EqualsAndHashCode
@PrimaryKeyClass
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderInfoKey implements Serializable{
	
/**
	 * 
	 */
	private static final long serialVersionUID = 189789L;

	@PrimaryKeyColumn(name = "cust_nbr", type = PrimaryKeyType.PARTITIONED)
	private String custnbr;
	
	@PrimaryKeyColumn(name= "order_nbr", type = PrimaryKeyType.CLUSTERED, ordinal = 0)
	private String orderNbr;

	@PrimaryKeyColumn(name = "service_id", type = PrimaryKeyType.CLUSTERED, ordinal = 1)
	private String serviceId;
	


}
