package io.lumen.hyperscalers.orders.service;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailAlertService {

	private static final Logger logger = LogManager.getLogger(EmailAlertService.class);

	@Autowired
	JavaMailSender mailSender;
	
	@Value("${hyper.mail.recipients}")
	String recipients;
	
	@Value("${hyper.mail.sender: noreply@lumen.com}")
	String sender;

	public void sendEmailNotification(String msg, String subject) {
		logger.info("Email sentfgs ....... "+" "+subject);
		MimeMessage mimeMessage = mailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
			helper.setFrom(new InternetAddress(sender));
			helper.setSubject(subject);
			helper.setTo(recipients.split(","));
			helper.setText(msg, true);
			mailSender.send(mimeMessage);
			logger.info("Email sent .......");
		}catch (Exception e) {
			logger.error("ExceptionUtils.getStackTrace "+ExceptionUtils.getStackTrace(e));		
			}
		
	}


}
