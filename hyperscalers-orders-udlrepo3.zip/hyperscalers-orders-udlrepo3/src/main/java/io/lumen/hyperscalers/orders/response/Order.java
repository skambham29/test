package io.lumen.hyperscalers.orders.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Order {
	
	@Schema (example = "551715368", description = "Parent order number")
	private String orderNumber;
	private String customerNumber;
	@JacksonXmlElementWrapper(localName = "serviceOrders")
    @JacksonXmlProperty(localName = "serviceOrder")
	private List<ServiceOrder> serviceOrders;

}
