package io.lumen.hyperscalers.orders.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.lumen.hyperscalers.orders.entity.hyperscalers.OrderInfo;
import io.lumen.hyperscalers.orders.repository.hyperscalers.OrderInfoRepository;

@Service
public class CassandraService {
	
	private static final Logger logger = LogManager.getLogger(CassandraService.class);
	@Autowired
	OrderInfoRepository orderInfoRepository;

	
	public List<OrderInfo> getOrdersByCustomerOrderNumber(String customerOrderNumber, List<String> custNbrs)
	{
		
		
			logger.info("customerOrderNumber.get() casserv1 "+custNbrs.size()+" "+customerOrderNumber);
			List<OrderInfo> orderData = new ArrayList<>();
			custNbrs.forEach(custNbr -> {
				List<OrderInfo> orderDataTemp =  orderInfoRepository.findBycustOrderNbrAndCustnbr(customerOrderNumber, custNbr);
				if (orderDataTemp.size() > 0 ) orderData.addAll(orderDataTemp);
			});
			return orderData;
		
	}
	
	
	
	
	public List<OrderInfo> getAllOrdersByCustNbrlst(List<String> custNbrs)
	{	
		
			logger.info("customerOrderNumber.get() casserv4 "+ custNbrs.toString());
			
			
			
			List<OrderInfo> orderData = new ArrayList<>();
			custNbrs.forEach(custNbr -> {
				List<OrderInfo> orderDataTemp =  orderInfoRepository.findByCustnbr(custNbr);
				if (orderDataTemp.size() > 0 ) orderData.addAll(orderDataTemp);
			});
			return orderData;
	}
	

	
}
