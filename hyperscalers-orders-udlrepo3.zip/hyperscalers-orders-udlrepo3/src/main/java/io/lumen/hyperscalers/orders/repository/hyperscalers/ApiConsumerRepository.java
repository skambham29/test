package io.lumen.hyperscalers.orders.repository.hyperscalers;


import org.springframework.data.cassandra.repository.CassandraRepository;

import io.lumen.hyperscalers.orders.entity.hyperscalers.ApiConsumer;

public interface ApiConsumerRepository extends CassandraRepository<ApiConsumer, String> {


}
