package io.lumen.hyperscalers.orders.repository.hyperscalers;

import java.util.List;

import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import io.lumen.hyperscalers.orders.entity.hyperscalers.OrderInfo;
import io.lumen.hyperscalers.orders.entity.hyperscalers.OrderInfoKey;





@Repository
public interface OrderInfoRepository extends CassandraRepository<OrderInfo, OrderInfoKey> {
	

	
	@AllowFiltering
	List<OrderInfo> findByCustnbr(String custNbr);
	
	@AllowFiltering
	List<OrderInfo> findBycustOrderNbrAndCustnbr(String customerOrderNumber, String custNbr);
	
}
