package io.lumen.hyperscalers.orders.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.lumen.hyperscalers.orders.entity.hyperscalers.OrderInfo;
import io.lumen.hyperscalers.orders.exception.OrderNotFoundException;
import io.lumen.hyperscalers.orders.model.Consumer;
import io.lumen.hyperscalers.orders.response.IpConfig;
import io.lumen.hyperscalers.orders.response.Milestone;
import io.lumen.hyperscalers.orders.response.Order;
import io.lumen.hyperscalers.orders.response.ServiceOrder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Service
public class OrderInformationService {

    private static final Logger logger = LogManager.getLogger(OrderInformationService.class);

    @Autowired
    Consumer consumer;
    
    @Autowired
    CassandraService cass;


    public List<Order> getOrderInformation(Optional<List<String>> services, Optional<String> customerOrderNumber, Optional<List<String>> orderStatuses, List<String> custnbrlst) {
    	
    	Map<String, Map<String, ServiceOrder>> mpsrvo = null;
    	 
    	 List<Order> orders = new ArrayList<>();

    	
	    	 if (orderStatuses.isPresent() && !services.isPresent() && !customerOrderNumber.isPresent())
	    	 {

	    		 List<OrderInfo> lstoi = cass.getAllOrdersByCustNbrlst(custnbrlst);
				 lstoi = lstoi.stream().filter(oi ->  orderStatuses.get().stream().map(s -> s.toLowerCase()).collect(Collectors.toList()).contains(oi.getOrderStatus().toLowerCase()))
				 .collect(Collectors.toList());
				 mpsrvo = mergeOrderInformation(lstoi);
	    		 
	    	 }
	    	 
	    	 if(orderStatuses.isPresent() && services.isPresent() && !customerOrderNumber.isPresent())
	    	 {
				
	    		 List<OrderInfo> lstoi = cass.getAllOrdersByCustNbrlst(custnbrlst);
				 lstoi = lstoi.stream()
						 .filter(oi ->  services.get().stream().map(s -> s.toLowerCase()).collect(Collectors.toList()).contains(oi.getServiceNameNormalized().toLowerCase()))
						 .filter(oi ->  orderStatuses.get().stream().map(s -> s.toLowerCase()).collect(Collectors.toList()).contains(oi.getOrderStatus().toLowerCase()))
				 .collect(Collectors.toList());
				 mpsrvo = mergeOrderInformation(lstoi);
	    		 
	    	 }
	    	 
	    	 if(customerOrderNumber.isPresent())
	    	 {
				 List<OrderInfo> lstoi = cass.getOrdersByCustomerOrderNumber(customerOrderNumber.get(), custnbrlst);
				 if (lstoi == null || lstoi.size() == 0) {
					 throw new OrderNotFoundException(customerOrderNumber.get());
				 }
				 mpsrvo = mergeOrderInformation(lstoi);
	    		 
	    	 }
	    	 if(services.isPresent()&& !customerOrderNumber.isPresent() && !orderStatuses.isPresent())
	    	 {
				
				 List<OrderInfo> lstoi = cass.getAllOrdersByCustNbrlst(custnbrlst);
				 lstoi = lstoi.stream()
						 .filter(oi ->  services.get().stream().map(s -> s.toLowerCase()).collect(Collectors.toList()).contains(oi.getServiceNameNormalized().toLowerCase()))
				 .collect(Collectors.toList());
				 mpsrvo = mergeOrderInformation(lstoi);
	    	}
	    	 
	    	 if(!services.isPresent() && !customerOrderNumber.isPresent() && !orderStatuses.isPresent())
	    	 {
				 logger.info("consumer.getCustNbrs().str[0]5 "+custnbrlst.toString());
				 List<OrderInfo> lstoi = cass.getAllOrdersByCustNbrlst(custnbrlst);
				 logger.info("lstoi size "+lstoi.size());
				 mpsrvo = mergeOrderInformation(lstoi);
	    	 }
	    	 
	    	 
    	 orders = mpsrvo.entrySet().stream().map(entry -> new Order(entry.getKey().split(",")[0], entry.getKey().split(",")[1], new ArrayList<>(entry.getValue().values())))
                 .collect(Collectors.toList());
    	 return orders;
    }
    
    public Map<String, Map<String, ServiceOrder>> mergeOrderInformation(List<OrderInfo> lstoi) {
		Map<String, Map<String, ServiceOrder>> target = new HashMap<>();

		lstoi.stream().forEach(order -> {

			Map<String, ServiceOrder> serviceOrders = target.containsKey(order.getOrderInfoKey().getOrderNbr())
					? target.get(order.getOrderInfoKey().getOrderNbr())
					: new HashMap<>();

			ServiceOrder serviceOrder = new ServiceOrder();
			
			serviceOrder.setServiceType(order.getServiceType());
			serviceOrder.setDescription(order.getDescription());
			Optional.ofNullable(order.getOrderReceivedDt())
					.ifPresent(dt -> serviceOrder.setOrderReceivedDate(dt.toString()));
			Optional.ofNullable(order.getOrigRequestedDueDt())
					.ifPresent(dt -> serviceOrder.setOriginalRequestedDueDate(dt.toString()));
			Optional.ofNullable(order.getFirmOrderCompletionDt())
					.ifPresent(dt -> serviceOrder.setFirmOrderConfirmationDate(dt.toString()));
			Optional.ofNullable(order.getActualDeliveryDt())
					.ifPresent(dt -> serviceOrder.setActualDeliveryDate(dt.toString()));
			Optional.ofNullable(order.getCustOrderNbr())
					.ifPresent(custPon -> serviceOrder.setCustomerOrderNumber(custPon));
			serviceOrder.setServiceId(order.getOrderInfoKey().getServiceId());
			serviceOrder.setService(order.getServiceNameNormalized());
			Optional.ofNullable(order.getCurrCustCommitDt())
					.ifPresent(dt -> serviceOrder.setCurrentCustomerCommitDate(dt.toString()));
			serviceOrder.setUltimateA(order.getUltimateA());
			serviceOrder.setCfaEndA(order.getCfaEndA());
			serviceOrder.setUltimateZ(order.getUltimateZ());
			serviceOrder.setCfaEndZ(order.getCfaEndZ());
			Optional.ofNullable(order.getServiceEndDt())
					.ifPresent(dt ->serviceOrder.setServiceEndDate(dt.toString()));
			serviceOrder.setVendorName(order.getVendorName());
			Optional.ofNullable(order.getContractSignDt())
					.ifPresent(dt -> serviceOrder.setContractSignedDate(dt.toString()));
			 
			List<String> ci = new ArrayList<>();
			if (order.getCircuitId() != null)
				ci.addAll(order.getCircuitId());

			serviceOrder.setCircuitIds(ci);

			Milestone ms1 = new Milestone();
			Milestone ms2 = new Milestone();
			Milestone ms3 = new Milestone();
			Milestone ms4 = new Milestone();
			ms1.setName(order.getMilestone1Name());
			ms1.setStatus(order.getMilestone1Status());
			Optional.ofNullable(order.getMilestone1StartDt()).ifPresent(dt -> ms1.setStartDate(dt.toString()));
			Optional.ofNullable(order.getMilestone1LastUpdatedDt())
					.ifPresent(dt -> ms1.setLastUpdatedDate(dt.toString()));
			Optional.ofNullable(order.getMilestone1CompletedDt()).ifPresent(dt -> ms1.setCompletedDate(dt.toString()));

			ms2.setName(order.getMilestone2Name());
			ms2.setStatus(order.getMilestone2Status());
			Optional.ofNullable(order.getMilestone2StartDt()).ifPresent(dt -> ms2.setStartDate(dt.toString()));
			Optional.ofNullable(order.getMilestone2LastUpdatedDt())
					.ifPresent(dt -> ms2.setLastUpdatedDate(dt.toString()));
			Optional.ofNullable(order.getMilestone2CompletedDt()).ifPresent(dt -> ms2.setCompletedDate(dt.toString()));

			ms3.setName(order.getMilestone3Name());
			ms3.setStatus(order.getMilestone3Status());
			Optional.ofNullable(order.getMilestone3StartDt()).ifPresent(dt -> ms3.setStartDate(dt.toString()));
			Optional.ofNullable(order.getMilestone3LastUpdatedDt())
					.ifPresent(dt -> ms3.setLastUpdatedDate(dt.toString()));
			Optional.ofNullable(order.getMilestone3CompletedDt()).ifPresent(dt -> ms3.setCompletedDate(dt.toString()));

			ms4.setName(order.getMilestone4Name());
			ms4.setStatus(order.getMilestone4Status());
			Optional.ofNullable(order.getMilestone4StartDt()).ifPresent(dt -> ms4.setStartDate(dt.toString()));
			Optional.ofNullable(order.getMilestone4LastUpdatedDt())
					.ifPresent(dt -> ms4.setLastUpdatedDate(dt.toString()));
			Optional.ofNullable(order.getMilestone4CompletedDt()).ifPresent(dt -> ms4.setCompletedDate(dt.toString()));
			List<Milestone> lstms = new ArrayList<Milestone>();
			lstms.add(ms1);
			lstms.add(ms2);
			lstms.add(ms3);
			lstms.add(ms4);
			serviceOrder.setMilestones(lstms);
			IpConfig ipc = new IpConfig();
			ipc.setIpVersion(order.getIpconfigIpVersion());
			ipc.setWanIpV4(order.getIpconfigWanipv4());
			ipc.setLanIpV4(order.getIpconfigLanipv4());
			ipc.setWanIpV6(order.getIpconfigWanipv6());
			ipc.setLanIpV6(order.getIpconfigLanipv6());
			ipc.setCustomerVlanId(order.getIpconfigCustomerVlanid());
			ipc.setExportPolicy(order.getIpconfigExportPolicy());
			ipc.setStaticRoute(order.getIpconfigStaticRoute());
			ipc.setMaintainer(order.getIpconfigMaintainer());
			ipc.setRoutingInstance(order.getIpconfigRoutingInstance());
			ipc.setAsNumber(order.getIpconfigAsNumber());
			ipc.setLocalAsNumber(order.getIpconfigLocalAsNumber());
			serviceOrder.setIpConfig(ipc);

			serviceOrders.put(order.getOrderInfoKey().getServiceId(), serviceOrder);

			target.put(order.getOrderInfoKey().getOrderNbr() + "," + order.getOrderInfoKey().getCustnbr(),
					serviceOrders);

		});
		return target;
	}
    
}