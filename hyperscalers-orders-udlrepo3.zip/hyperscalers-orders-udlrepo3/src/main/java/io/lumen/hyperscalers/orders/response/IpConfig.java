package io.lumen.hyperscalers.orders.response;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
public class IpConfig {
	
    private String ipVersion;
    private String wanIpV4;
  
    private String lanIpV4;
    private String wanIpV6;
    
    private String lanIpV6;
    
    private String customerVlanId;	 
   
    private String exportPolicy;	 
  
    private String staticRoute;
    private String maintainer;
    private String routingInstance;
   
    private String asNumber;	 
    private String localAsNumber;
    

}
