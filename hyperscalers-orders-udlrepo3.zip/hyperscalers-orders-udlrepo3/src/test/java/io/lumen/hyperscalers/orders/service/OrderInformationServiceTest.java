package io.lumen.hyperscalers.orders.service;


import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.lumen.hyperscalers.orders.constants.Constants;
import io.lumen.hyperscalers.orders.entity.hyperscalers.OrderInfo;
import io.lumen.hyperscalers.orders.entity.hyperscalers.OrderInfoKey;
import io.lumen.hyperscalers.orders.exception.OrderNotFoundException;
import io.lumen.hyperscalers.orders.repository.hyperscalers.OrderInfoRepository;
import io.lumen.hyperscalers.orders.response.IpConfig;
import io.lumen.hyperscalers.orders.response.Milestone;
import io.lumen.hyperscalers.orders.response.Order;
import io.lumen.hyperscalers.orders.response.ServiceOrder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;


@SpringBootTest (classes = {OrderInformationServiceTest.class})
public class OrderInformationServiceTest {

    private static final Logger logger = LogManager.getLogger(OrderInformationServiceTest.class);
    
    @InjectMocks
    private OrderInformationService orderInformationService;
    @Mock
    private CassandraService cass;

    @Test    
    public void getOrderInformationTestnoParamPassed() {
    	
    	Optional<List<String>> services= Optional.ofNullable(null);
    	Optional<String> customerOrderNumber=  Optional.ofNullable(null);
    	Optional<List<String>> orderStatuses= Optional.ofNullable(null); 	 
    	List<String> custnbrlst =new ArrayList<String>();
    	 custnbrlst.add("4413");  
    	 OrderInfoKey oik = new OrderInfoKey();
    	 oik.setOrderNbr("551822320");
    	 oik.setServiceId("442250299");
    	 oik.setCustnbr("4413");
    	 List<String> lci = new ArrayList<>();
         lci.add("442351960");
    	 List<OrderInfo> mockOrderInfoLst = Collections.singletonList(new OrderInfo(oik, "Wavelength", "100GIG-E",  
		 LocalDate.of(2021,02,25), LocalDate.of(2021,03,04), LocalDate.of(2021,03,04), LocalDate.of(2021,03,01), 
		 "TRIM.20200513.08", "Wavelength", LocalDate.of(2021,03,04),  
		 "21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA", null, "601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA", 
		 null, null, "Lumen", null, lci,null, null, null, null, null, null, null, null, null, null, null, null, "PLAN", "COMPLETE_REFLECTION", LocalDate.of(2021,02,25), 
		 LocalDate.of(2021,02,25), null, "DESIGN", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, 
		 "BUILD", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, "ACTIVATE", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), 
		 LocalDate.of(2021,03,01), null, "in progress", "","Wavelength","Wavelength"));
    	 when(cass.getAllOrdersByCustNbrlst(custnbrlst)).thenReturn(mockOrderInfoLst);
    	List<Order> actualResponse = orderInformationService.getOrderInformation(services, customerOrderNumber, orderStatuses, custnbrlst);
		 Order or = new Order();
		 or.setOrderNumber("551822320");
		 ServiceOrder so = new ServiceOrder();
		 so.setActualDeliveryDate(LocalDate.of(2021,03,01).toString());
		 so.setCfaEndA(null);
		 so.setCfaEndZ(null);
		 so.setContractSignedDate(null);
		 so.setCurrentCustomerCommitDate(LocalDate.of(2021,03,04).toString());
		 so.setCustomerOrderNumber("TRIM.20200513.08");
		 so.setDescription("100GIG-E");
		 so.setFirmOrderConfirmationDate(LocalDate.of(2021,03,04).toString());
		 //so.setInstallInterval("45 (days)");
		 IpConfig ipc = new IpConfig();
		 so.setIpConfig(ipc);
		 Milestone ms = new Milestone();
		 ms.setStatus("COMPLETE_REFLECTION");
		 ms.setStartDate(LocalDate.of(2021,02,25).toString());
		 ms.setCompletedDate(LocalDate.of(2021,02,25).toString());
		 ms.setLastUpdatedDate(null);
		 ms.setName("PLAN");
		 Milestone ms1 = new Milestone();
		 ms1.setStatus("COMPLETE_REFLECTION");
		 ms1.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms1.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms1.setLastUpdatedDate(null);
		 ms1.setName("DESIGN");
		 Milestone ms2 = new Milestone();
		 ms2.setStatus("COMPLETE_REFLECTION");
		 ms2.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms2.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms2.setLastUpdatedDate(null);
		 ms2.setName("BUILD");
		 Milestone ms3 = new Milestone();
		 ms3.setStatus("COMPLETE_REFLECTION");
		 ms3.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms3.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms3.setLastUpdatedDate(null);
		 ms3.setName("ACTIVATE");
		 List<Milestone> lstm = new ArrayList<Milestone>();
		 lstm.add(ms);
		 lstm.add(ms1);
		 lstm.add(ms2);
		 lstm.add(ms3);
		 so.setMilestones(lstm);
		 so.setOrderReceivedDate(LocalDate.of(2021,02,25).toString());
		 so.setOriginalRequestedDueDate(LocalDate.of(2021,03,04).toString());
		 so.setService("Wavelength");
		 so.setServiceEndDate(null);
		 so.setServiceId("442250299");
		 so.setServiceType("Wavelength");
		 so.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
		 so.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
		 so.setVendorName("Lumen");
		// so.setCircuitId("442351960");
		 List<String> ci = new ArrayList<>();
	        ci.add("442351960");
	        so.setCircuitIds(ci);
		 
		 assertTrue(actualResponse.get(0).getOrderNumber().equals("551822320"));
		 assertTrue(actualResponse.get(0).getServiceOrders().get(0).equals(so));
	     assertEquals(1, actualResponse.size());
		
}  
    
    @Test
 	public void getOrderInformationTestwithParamServices() {
   	 
		
	 Optional<String> customerOrderNumber=  Optional.ofNullable(null);
	 Optional<List<String>> orderStatuses= Optional.ofNullable(null); 	 
	 Optional<List<String>> services= Optional.of(new ArrayList<String>());
	 services.get().add("Wavelength");
	 List<String> custnbrlst =new ArrayList<String>();
	 custnbrlst.add("4413"); OrderInfoKey oik = new OrderInfoKey();
	 oik.setOrderNbr("551822320");
	 oik.setServiceId("442250299");
	 oik.setCustnbr("4413");
	 List<String> lci = new ArrayList<>();
     lci.add("442351960");
	 List<OrderInfo> mockOrderInfoLst = Collections.singletonList(new OrderInfo(oik, "Wavelength", "100GIG-E",  
		LocalDate.of(2021,02,25), LocalDate.of(2021,03,04), LocalDate.of(2021,03,04), LocalDate.of(2021,03,01), 
		"TRIM.20200513.08", "Wavelength", LocalDate.of(2021,03,04),  
		"21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA", null, "601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA", 
		null, null, "Lumen", null, lci, null, null, null, null, null, null, null, null, null, null, null, null, "PLAN", "COMPLETE_REFLECTION", LocalDate.of(2021,02,25), 
		LocalDate.of(2021,02,25), null, "DESIGN", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, 
		"BUILD", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, "ACTIVATE", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), 
		LocalDate.of(2021,03,01), null, "in progress", "4413","Wavelength","Wavelength"));
    	when(cass.getAllOrdersByCustNbrlst(custnbrlst)).thenReturn(mockOrderInfoLst);
    	List<Order> actualResponse = orderInformationService.getOrderInformation(services, customerOrderNumber, orderStatuses, custnbrlst);
    	 Order or = new Order();
		 or.setOrderNumber("551822320");
		 or.setCustomerNumber("4413");
		 ServiceOrder so = new ServiceOrder();
		 so.setActualDeliveryDate(LocalDate.of(2021,03,01).toString());
		 so.setCfaEndA(null);
		 so.setCfaEndZ(null);
		 so.setContractSignedDate(null);
		 so.setCurrentCustomerCommitDate(LocalDate.of(2021,03,04).toString());
		 so.setCustomerOrderNumber("TRIM.20200513.08");
		 so.setDescription("100GIG-E");
		 so.setFirmOrderConfirmationDate(LocalDate.of(2021,03,04).toString());
		 //so.setInstallInterval("45 (days)");
		 IpConfig ipc = new IpConfig();
		 so.setIpConfig(ipc);
		 Milestone ms = new Milestone();
		 ms.setStatus("COMPLETE_REFLECTION");
		 ms.setStartDate(LocalDate.of(2021,02,25).toString());
		 ms.setCompletedDate(LocalDate.of(2021,02,25).toString());
		 ms.setLastUpdatedDate(null);
		 ms.setName("PLAN");
		 Milestone ms1 = new Milestone();
		 ms1.setStatus("COMPLETE_REFLECTION");
		 ms1.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms1.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms1.setLastUpdatedDate(null);
		 ms1.setName("DESIGN");
		 Milestone ms2 = new Milestone();
		 ms2.setStatus("COMPLETE_REFLECTION");
		 ms2.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms2.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms2.setLastUpdatedDate(null);
		 ms2.setName("BUILD");
		 Milestone ms3 = new Milestone();
		 ms3.setStatus("COMPLETE_REFLECTION");
		 ms3.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms3.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms3.setLastUpdatedDate(null);
		 ms3.setName("ACTIVATE");
		 List<Milestone> lstm = new ArrayList<Milestone>();
		 lstm.add(ms);
		 lstm.add(ms1);
		 lstm.add(ms2);
		 lstm.add(ms3);
		 so.setMilestones(lstm);
		 so.setOrderReceivedDate(LocalDate.of(2021,02,25).toString());
		 so.setOriginalRequestedDueDate(LocalDate.of(2021,03,04).toString());
		 so.setService("Wavelength");
		 so.setServiceEndDate(null);
		 so.setServiceId("442250299");
		 so.setServiceType("Wavelength");
		 so.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
		 so.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
		 so.setVendorName("Lumen");
	     so.setCircuitIds(lci);
		 
		 assertTrue(actualResponse.get(0).getOrderNumber().equals("551822320"));
		 assertTrue(actualResponse.get(0).getCustomerNumber().equals("4413"));
		 assertTrue(actualResponse.get(0).getServiceOrders().get(0).equals(so));
	     assertEquals(1, actualResponse.size());
 	}
 	
 	@Test
 	public void getOrderInformationTestwithParamcustomerOrderNumber() {
 	
	 Optional<List<String>> services= Optional.ofNullable(null);
	 Optional<String> customerOrderNumber= Optional.of("TRIM.20200513.08"); 
	 Optional<List<String>> orderStatuses= Optional.ofNullable(null); 	 
	 List<String> custnbrlst =new ArrayList<String>();
	 custnbrlst.add("4413");
	 OrderInfoKey oik = new OrderInfoKey();
	 oik.setOrderNbr("551822320");
	 oik.setServiceId("442250299");
	 oik.setCustnbr("4413");
	 List<String> lci = new ArrayList<>();
     lci.add("442351960");
	 List<OrderInfo> mockOrderInfoLst = Collections.singletonList(new OrderInfo(oik, "Wavelength", "100GIG-E",  
		LocalDate.of(2021,02,25), LocalDate.of(2021,03,04), LocalDate.of(2021,03,04), LocalDate.of(2021,03,01), 
		"TRIM.20200513.08", "Wavelength", LocalDate.of(2021,03,04),  
		"21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA", null, "601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA", 
		null, null, "Lumen", null, lci, null, null, null, null, null, null, null, null, null, null, null, null, "PLAN", "COMPLETE_REFLECTION", LocalDate.of(2021,02,25), 
		LocalDate.of(2021,02,25), null, "DESIGN", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, 
		"BUILD", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, "ACTIVATE", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), 
		LocalDate.of(2021,03,01), null, "in progress", "4413", "Wavelength", "Wavelength"));
	    when(cass.getOrdersByCustomerOrderNumber(customerOrderNumber.get(), custnbrlst)).thenReturn(mockOrderInfoLst);
	 	List<Order> actualResponse = orderInformationService.getOrderInformation(services, customerOrderNumber, orderStatuses, custnbrlst);
	 	 Order or = new Order();
		 or.setOrderNumber("551822320");
		 or.setCustomerNumber("4413");
		 ServiceOrder so = new ServiceOrder();
		 so.setActualDeliveryDate(LocalDate.of(2021,03,01).toString());
		 so.setCfaEndA(null);
		 so.setCfaEndZ(null);
		 so.setContractSignedDate(null);
		 so.setCurrentCustomerCommitDate(LocalDate.of(2021,03,04).toString());
		 so.setCustomerOrderNumber("TRIM.20200513.08");
		 so.setDescription("100GIG-E");
		 so.setFirmOrderConfirmationDate(LocalDate.of(2021,03,04).toString());
		 //so.setInstallInterval("45 (days)");
		 IpConfig ipc = new IpConfig();
		 so.setIpConfig(ipc);
		 Milestone ms = new Milestone();
		 ms.setStatus("COMPLETE_REFLECTION");
		 ms.setStartDate(LocalDate.of(2021,02,25).toString());
		 ms.setCompletedDate(LocalDate.of(2021,02,25).toString());
		 ms.setLastUpdatedDate(null);
		 ms.setName("PLAN");
		 Milestone ms1 = new Milestone();
		 ms1.setStatus("COMPLETE_REFLECTION");
		 ms1.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms1.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms1.setLastUpdatedDate(null);
		 ms1.setName("DESIGN");
		 Milestone ms2 = new Milestone();
		 ms2.setStatus("COMPLETE_REFLECTION");
		 ms2.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms2.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms2.setLastUpdatedDate(null);
		 ms2.setName("BUILD");
		 Milestone ms3 = new Milestone();
		 ms3.setStatus("COMPLETE_REFLECTION");
		 ms3.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms3.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms3.setLastUpdatedDate(null);
		 ms3.setName("ACTIVATE");
		 List<Milestone> lstm = new ArrayList<Milestone>();
		 lstm.add(ms);
		 lstm.add(ms1);
		 lstm.add(ms2);
		 lstm.add(ms3);
		 so.setMilestones(lstm);
		 so.setOrderReceivedDate(LocalDate.of(2021,02,25).toString());
		 so.setOriginalRequestedDueDate(LocalDate.of(2021,03,04).toString());
		 so.setService("Wavelength");
		 so.setServiceEndDate(null);
		 so.setServiceId("442250299");
		 so.setServiceType("Wavelength");
		 so.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
		 so.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
		 so.setVendorName("Lumen");
		 so.setCircuitIds(lci);
		 
		 assertTrue(actualResponse.get(0).getOrderNumber().equals("551822320"));
		 assertTrue(actualResponse.get(0).getCustomerNumber().equals("4413"));
		 assertTrue(actualResponse.get(0).getServiceOrders().get(0).equals(so));
	     assertEquals(1, actualResponse.size());
 	}
 	
 	@Test
 	public void getOrderInformationTestwithParamStatusesServices() {
 	
	 Map<String, Map<String, ServiceOrder>> mpsrvo = null;
	 Optional<List<String>> services= Optional.of(new ArrayList<String>());
	 Optional<String> customerOrderNumber=  Optional.ofNullable(null); 
	 Optional<List<String>> orderStatuses= Optional.of(new ArrayList<String>()); 	 
	 services.get().add("Wavelength");
	 orderStatuses.get().add("in progress");
	 List<String> custnbrlst =new ArrayList<String>();
	 custnbrlst.add("4413");
	 OrderInfoKey oik = new OrderInfoKey();
	 oik.setOrderNbr("551822320");
	 oik.setServiceId("442250299");
	 oik.setCustnbr("4413");
	 List<String> lci = new ArrayList<>();
     lci.add("442351960");
	 List<OrderInfo> mockOrderInfoLst = Collections.singletonList(new OrderInfo(oik, "Wavelength", "100GIG-E",  
		LocalDate.of(2021,02,25), LocalDate.of(2021,03,04), LocalDate.of(2021,03,04), LocalDate.of(2021,03,01), 
		"TRIM.20200513.08", "Wavelength", LocalDate.of(2021,03,04),  
		"21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA", null, "601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA", 
		null, null, "Lumen", null, lci, null, null, null, null, null, null, null, null, null, null, null, null, "PLAN", "COMPLETE_REFLECTION", LocalDate.of(2021,02,25), 
		LocalDate.of(2021,02,25), null, "DESIGN", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, 
		"BUILD", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, "ACTIVATE", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), 
		LocalDate.of(2021,03,01), null, "in progress", "4413", "Wavelength", "Wavelength"));
	    when(cass.getAllOrdersByCustNbrlst(custnbrlst)).thenReturn(mockOrderInfoLst);
	 	List<Order> actualResponse = orderInformationService.getOrderInformation(services, customerOrderNumber, orderStatuses, custnbrlst);
	 	 Order or = new Order();
		 or.setOrderNumber("551822320");
		 or.setCustomerNumber("4413");
		 ServiceOrder so = new ServiceOrder();
		 so.setActualDeliveryDate(LocalDate.of(2021,03,01).toString());
		 so.setCfaEndA(null);
		 so.setCfaEndZ(null);
		 so.setContractSignedDate(null);
		 so.setCurrentCustomerCommitDate(LocalDate.of(2021,03,04).toString());
		 so.setCustomerOrderNumber("TRIM.20200513.08");
		 so.setDescription("100GIG-E");
		 so.setFirmOrderConfirmationDate(LocalDate.of(2021,03,04).toString());
		// so.setInstallInterval("45 (days)");
		 IpConfig ipc = new IpConfig();
		 so.setIpConfig(ipc);
		 Milestone ms = new Milestone();
		 ms.setStatus("COMPLETE_REFLECTION");
		 ms.setStartDate(LocalDate.of(2021,02,25).toString());
		 ms.setCompletedDate(LocalDate.of(2021,02,25).toString());
		 ms.setLastUpdatedDate(null);
		 ms.setName("PLAN");
		 Milestone ms1 = new Milestone();
		 ms1.setStatus("COMPLETE_REFLECTION");
		 ms1.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms1.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms1.setLastUpdatedDate(null);
		 ms1.setName("DESIGN");
		 Milestone ms2 = new Milestone();
		 ms2.setStatus("COMPLETE_REFLECTION");
		 ms2.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms2.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms2.setLastUpdatedDate(null);
		 ms2.setName("BUILD");
		 Milestone ms3 = new Milestone();
		 ms3.setStatus("COMPLETE_REFLECTION");
		 ms3.setStartDate(LocalDate.of(2021,03,01).toString());
		 ms3.setCompletedDate(LocalDate.of(2021,03,01).toString());
		 ms3.setLastUpdatedDate(null);
		 ms3.setName("ACTIVATE");
		 List<Milestone> lstm = new ArrayList<Milestone>();
		 lstm.add(ms);
		 lstm.add(ms1);
		 lstm.add(ms2);
		 lstm.add(ms3);
		 so.setMilestones(lstm);
		 so.setOrderReceivedDate(LocalDate.of(2021,02,25).toString());
		 so.setOriginalRequestedDueDate(LocalDate.of(2021,03,04).toString());
		 so.setService("Wavelength");
		 so.setServiceEndDate(null);
		 so.setServiceId("442250299");
		 so.setServiceType("Wavelength");
		 so.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
		 so.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
		 so.setVendorName("Lumen");
	     so.setCircuitIds(lci);
	     
		 assertTrue(actualResponse.get(0).getOrderNumber().equals("551822320"));
		 assertTrue(actualResponse.get(0).getCustomerNumber().equals("4413"));
		 assertTrue(actualResponse.get(0).getServiceOrders().get(0).equals(so));
	     assertEquals(1, actualResponse.size());
 	}
 	
 	@Test
 	public void getOrderInformationTestwithParamStatuses() {
 	
 		 Optional<List<String>> services= Optional.ofNullable(null);
 		 Optional<String> customerOrderNumber=  Optional.ofNullable(null); 
 		 Optional<List<String>> orderStatuses= Optional.of(new ArrayList<String>()); 	 
 		 orderStatuses.get().add("in progress");
 		 List<String> custnbrlst =new ArrayList<String>();
 		 custnbrlst.add("4413");
 		 OrderInfoKey oik = new OrderInfoKey();
 		 oik.setOrderNbr("551822320");
 		 oik.setServiceId("442250299");
 		 oik.setCustnbr("4413");
 		 List<String> lci = new ArrayList<>();
 	     lci.add("442351960");
 		 List<OrderInfo> mockOrderInfoLst = Collections.singletonList(new OrderInfo(oik, "Wavelength", "100GIG-E",  
 			LocalDate.of(2021,02,25), LocalDate.of(2021,03,04), LocalDate.of(2021,03,04), LocalDate.of(2021,03,01), 
 			"TRIM.20200513.08", "Wavelength", LocalDate.of(2021,03,04),  
 			"21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA", null, "601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA", 
 			null, null, "Lumen", null, lci ,null, null, null, null, null, null, null, null, null, null, null, null, "PLAN", "COMPLETE_REFLECTION", LocalDate.of(2021,02,25), 
 			LocalDate.of(2021,02,25), null, "DESIGN", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, 
 			"BUILD", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, "ACTIVATE", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), 
 			LocalDate.of(2021,03,01), null, "in progress", "4413", "Wavelength", "Wavelength"));
 		    when(cass.getAllOrdersByCustNbrlst(custnbrlst)).thenReturn(mockOrderInfoLst);
 		 	List<Order> actualResponse = orderInformationService.getOrderInformation(services, customerOrderNumber, orderStatuses, custnbrlst);
 		 	 Order or = new Order();
 			 or.setOrderNumber("551822320");
 			 or.setCustomerNumber("4413");
 			 ServiceOrder so = new ServiceOrder();
 			 so.setActualDeliveryDate(LocalDate.of(2021,03,01).toString());
 			 so.setCfaEndA(null);
 			 so.setCfaEndZ(null);
 			 so.setContractSignedDate(null);
 			 so.setCurrentCustomerCommitDate(LocalDate.of(2021,03,04).toString());
 			 so.setCustomerOrderNumber("TRIM.20200513.08");
 			 so.setDescription("100GIG-E");
 			 so.setFirmOrderConfirmationDate(LocalDate.of(2021,03,04).toString());
 			 //so.setInstallInterval("45 (days)");
 			 IpConfig ipc = new IpConfig();
 			 so.setIpConfig(ipc);
 			 Milestone ms = new Milestone();
 			 ms.setStatus("COMPLETE_REFLECTION");
 			 ms.setStartDate(LocalDate.of(2021,02,25).toString());
 			 ms.setCompletedDate(LocalDate.of(2021,02,25).toString());
 			 ms.setLastUpdatedDate(null);
 			 ms.setName("PLAN");
 			 Milestone ms1 = new Milestone();
 			 ms1.setStatus("COMPLETE_REFLECTION");
 			 ms1.setStartDate(LocalDate.of(2021,03,01).toString());
 			 ms1.setCompletedDate(LocalDate.of(2021,03,01).toString());
 			 ms1.setLastUpdatedDate(null);
 			 ms1.setName("DESIGN");
 			 Milestone ms2 = new Milestone();
 			 ms2.setStatus("COMPLETE_REFLECTION");
 			 ms2.setStartDate(LocalDate.of(2021,03,01).toString());
 			 ms2.setCompletedDate(LocalDate.of(2021,03,01).toString());
 			 ms2.setLastUpdatedDate(null);
 			 ms2.setName("BUILD");
 			 Milestone ms3 = new Milestone();
 			 ms3.setStatus("COMPLETE_REFLECTION");
 			 ms3.setStartDate(LocalDate.of(2021,03,01).toString());
 			 ms3.setCompletedDate(LocalDate.of(2021,03,01).toString());
 			 ms3.setLastUpdatedDate(null);
 			 ms3.setName("ACTIVATE");
 			 List<Milestone> lstm = new ArrayList<Milestone>();
 			 lstm.add(ms);
 			 lstm.add(ms1);
 			 lstm.add(ms2);
 			 lstm.add(ms3);
 			 so.setMilestones(lstm);
 			 so.setOrderReceivedDate(LocalDate.of(2021,02,25).toString());
 			 so.setOriginalRequestedDueDate(LocalDate.of(2021,03,04).toString());
 			 so.setService("Wavelength");
 			 so.setServiceEndDate(null);
 			 so.setServiceId("442250299");
 			 so.setServiceType("Wavelength");
 			 so.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
 			 so.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
 			 so.setVendorName("Lumen");
 	         so.setCircuitIds(lci);
 			 
 			 assertTrue(actualResponse.get(0).getOrderNumber().equals("551822320"));
 			 assertTrue(actualResponse.get(0).getCustomerNumber().equals("4413"));
 			 assertTrue(actualResponse.get(0).getServiceOrders().get(0).equals(so));
 		     assertEquals(1, actualResponse.size());
 	}
 	
 	@Test
 	public void getOrderInformationTestCustomerOrderNumberNotFound() {
 		Optional<List<String>> services= Optional.ofNullable(null);
		Optional<String> customerOrderNumber=  Optional.ofNullable("test-order-number"); 
		Optional<List<String>> orderStatuses= Optional.ofNullable(null);
		List<OrderInfo> emptyOrderInfoLst = new ArrayList<>(); 
		List<String> custnbrlst =new ArrayList<String>();
   	 	custnbrlst.add("4413");
		when(cass.getOrdersByCustomerOrderNumber(customerOrderNumber.get(), custnbrlst)).thenReturn(emptyOrderInfoLst);
		
		assertThrows(OrderNotFoundException.class, () -> {
			orderInformationService.getOrderInformation(services, customerOrderNumber, orderStatuses, custnbrlst);
		});
 	}
    
 	@Test
    public void mergeOrderInformationTest() throws JsonParseException, JsonMappingException, IOException {

    	Map<String, Map<String, ServiceOrder>> target = new HashMap<>();
    	Map<String, ServiceOrder> m1 = new HashMap<>();
    	ServiceOrder so11 = new ServiceOrder();
    	so11.setServiceType("Wavelength");
    	so11.setDescription("100GIG-E");
    	so11.setOrderReceivedDate(LocalDate.of(2021,02,25).toString());
    	so11.setOriginalRequestedDueDate(LocalDate.of(2021,03,04).toString());
    	so11.setFirmOrderConfirmationDate(LocalDate.of(2021,03,04).toString());
    	so11.setActualDeliveryDate(LocalDate.of(2021,03,01).toString());
    	so11.setServiceId("442250299");
    	so11.setCustomerOrderNumber("TRIM.20200513.08");
    	so11.setContractSignedDate(null);
    	//so11.setInstallInterval("45 (days)");
    	so11.setService("Wavelength");
    	so11.setCurrentCustomerCommitDate(LocalDate.of(2021,03,04).toString());
    	so11.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
    	so11.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
    	so11.setVendorName("Lumen");
   	 	List<String> lci = new ArrayList<>();
   	 	lci.add("442351960");
   	 	so11.setCircuitIds(lci);
    	
    	Milestone ms1 = new Milestone();
        Milestone ms2 = new Milestone();
        Milestone ms3 = new Milestone();
        Milestone ms4 = new Milestone();
        ms1.setStatus("COMPLETE_REFLECTION");
        ms1.setName("PLAN");
        ms1.setStartDate("2021-02-25");
        ms1.setCompletedDate("2021-03-01");
        ms1.setLastUpdatedDate(null);
        
        ms2.setStatus("COMPLETE_REFLECTION");
        ms2.setName("DESIGN");
        ms2.setStartDate("2021-03-01");
        ms2.setCompletedDate("2021-03-01");
        ms2.setLastUpdatedDate(null);
        
        ms3.setStatus("COMPLETE_REFLECTION");
        ms3.setName("BUILD");
        ms3.setStartDate("2021-03-01");
        ms3.setCompletedDate("2021-03-01");
        ms3.setLastUpdatedDate(null);
        
        ms4.setStatus("COMPLETE_REFLECTION");
        ms4.setName("ACTIVATE");
        ms4.setStartDate("2021-03-01");
        ms4.setCompletedDate("2021-03-01");
        ms4.setLastUpdatedDate(null);
        List<Milestone> lstms = new ArrayList<Milestone>();
        lstms.add(ms1); 
        lstms.add(ms2);
        lstms.add(ms3);
        lstms.add(ms4);
        so11.setMilestones(lstms);
        IpConfig ipc = new IpConfig();
        so11.setIpConfig(ipc);
    	m1.put(so11.getServiceId(), so11);
        target.put("551822320", m1);
        OrderInfoKey oik = new OrderInfoKey();
   	 	oik.setOrderNbr("551822320");
   	 	oik.setServiceId("442250299");
   	 	oik.setCustnbr("4413");
   	 	List<OrderInfo> mockOrderInfoLst = new ArrayList<OrderInfo>();
        mockOrderInfoLst.add(new OrderInfo(oik, "Wavelength", "100GIG-E",  
		 LocalDate.of(2021,02,25), LocalDate.of(2021,03,04), LocalDate.of(2021,03,04), LocalDate.of(2021,03,01), 
		 "TRIM.20200513.08", "Wavelength", LocalDate.of(2021,03,04),  
		 "21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA", null, "601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA", 
		 null, null, "Lumen", null,lci , null, null, null, null, null, null, null, null, null, null, null, null, "PLAN", "COMPLETE_REFLECTION", LocalDate.of(2021,02,25), 
		 LocalDate.of(2021,03,01), null, "DESIGN", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, 
		 "BUILD", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, "ACTIVATE", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), 
		 LocalDate.of(2021,03,01), null, "in progress", "4413","Wavelength", "Wavelength"));
        Map<String, Map<String, ServiceOrder>> mk =ReflectionTestUtils.invokeMethod(orderInformationService,"mergeOrderInformation",mockOrderInfoLst);
    	logger.info("mk size "+mk.size()+mk.keySet().toString()+mk.entrySet().toString());
    	String mkkey= mk.keySet().toString().split(",")[0].substring(1);
    	logger.info("mk size mkkey "+mkkey);
    	Set<String> setstr = new HashSet<String>();
    	setstr.add(mkkey);
    	Map<String, ServiceOrder> mso1 = target.get("551822320");
    	ServiceOrder so1 = mso1.get("442250299");
    	logger.info("mso1.size() "+mso1.size());
    	Map<String, ServiceOrder> mso2 = mk.get("551822320,4413");
    	logger.info("mso2 size "+mso2.size());
    	ServiceOrder so2 = mso2.get("442250299");
    	assertEquals(1,target.size());
    	assertTrue(target.keySet().equals(setstr));
    	assertTrue(mso1.keySet().equals(mso2.keySet()) && so1.getActualDeliveryDate().equals(so2.getActualDeliveryDate())
    			&& so1.getCfaEndA()==so2.getCfaEndA() && so1.getCfaEndZ()==so2.getCfaEndZ() && so1.getContractSignedDate()==so2.getContractSignedDate()
    			&& so1.getCurrentCustomerCommitDate().equals(so2.getCurrentCustomerCommitDate()) && so1.getCustomerOrderNumber().equals(so2.getCustomerOrderNumber())
    			&& so1.getDescription().equals(so2.getDescription()) && so1.getFirmOrderConfirmationDate().equals(so2.getFirmOrderConfirmationDate())
    			&& so1.getIpConfig().equals(so2.getIpConfig())
    			&& so1.getOrderReceivedDate().equals(so2.getOrderReceivedDate()) && so1.getOriginalRequestedDueDate().equals(so2.getOriginalRequestedDueDate())
    			&& so1.getService().equals(so2.getService()) && so1.getServiceEndDate()==so2.getServiceEndDate() && so1.getServiceType().equals(so2.getServiceType())
    			&& so1.getUltimateA().equals(so2.getUltimateA()) && so1.getUltimateZ().equals(so2.getUltimateZ()) && so1.getVendorName().equals(so2.getVendorName()) && so1.getCircuitIds().equals(so2.getCircuitIds())
    			&& so1.getMilestones().get(0).getName().equals(so2.getMilestones().get(0).getName())
    			&& so1.getMilestones().get(0).getStatus().equals(so2.getMilestones().get(0).getStatus())
    			&& so1.getMilestones().get(0).getStartDate().equals(so2.getMilestones().get(0).getStartDate())
    			&& so1.getMilestones().get(0).getCompletedDate().equals(so2.getMilestones().get(0).getCompletedDate())
    			&& so1.getMilestones().get(0).getLastUpdatedDate()==so2.getMilestones().get(0).getLastUpdatedDate()
				&& so1.getMilestones().get(1).getName().equals(so2.getMilestones().get(1).getName())
    			&& so1.getMilestones().get(1).getStatus().equals(so2.getMilestones().get(1).getStatus())
    			&& so1.getMilestones().get(1).getStartDate().equals(so2.getMilestones().get(1).getStartDate())
    			&& so1.getMilestones().get(1).getCompletedDate().equals(so2.getMilestones().get(1).getCompletedDate())
    			&& so1.getMilestones().get(1).getLastUpdatedDate()==so2.getMilestones().get(1).getLastUpdatedDate()
				&& so1.getMilestones().get(2).getName().equals(so2.getMilestones().get(2).getName())
    			&& so1.getMilestones().get(2).getStatus().equals(so2.getMilestones().get(2).getStatus())
    			&& so1.getMilestones().get(2).getStartDate().equals(so2.getMilestones().get(2).getStartDate())
    			&& so1.getMilestones().get(2).getCompletedDate().equals(so2.getMilestones().get(2).getCompletedDate())
    			&& so1.getMilestones().get(2).getLastUpdatedDate()==so2.getMilestones().get(2).getLastUpdatedDate()
				&& so1.getMilestones().get(3).getName().equals(so2.getMilestones().get(3).getName())
    			&& so1.getMilestones().get(3).getStatus().equals(so2.getMilestones().get(3).getStatus())
    			&& so1.getMilestones().get(3).getStartDate().equals(so2.getMilestones().get(3).getStartDate())
    			&& so1.getMilestones().get(3).getCompletedDate().equals(so2.getMilestones().get(3).getCompletedDate())
    			&& so1.getMilestones().get(3).getLastUpdatedDate()==so2.getMilestones().get(3).getLastUpdatedDate()
    			); 

		
}
    
}
