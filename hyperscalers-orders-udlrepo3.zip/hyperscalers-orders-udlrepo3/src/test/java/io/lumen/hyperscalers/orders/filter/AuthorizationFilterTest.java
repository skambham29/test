package io.lumen.hyperscalers.orders.filter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import io.jsonwebtoken.Header;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.lumen.hyperscalers.orders.config.AuthorizationConfig;
import io.lumen.hyperscalers.orders.entity.hyperscalers.ApiConsumer;
import io.lumen.hyperscalers.orders.model.Consumer;
import io.lumen.hyperscalers.orders.repository.hyperscalers.ApiConsumerRepository;
import io.lumen.hyperscalers.orders.resource.OrderResource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;
import java.util.Date;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;



@SpringBootTest (classes = {Consumer.class, ApiConsumerRepository.class})
public class AuthorizationFilterTest {
	
	@InjectMocks
	AuthorizationFilter authorizationFilter;
	
	@Mock
	ApiConsumerRepository apiConsumerRepository;
    
    @Mock
	Consumer consumer;
    
    MockHttpServletRequest request;
    MockHttpServletResponse response;
    MockFilterChain filterChain;
    String encodedPublicKey;
    String token;
    PrivateKey privateKey;
    
    
    @BeforeEach
    public void setup() throws NoSuchAlgorithmException {	
    	MockitoAnnotations.openMocks(this);
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		filterChain = new MockFilterChain();		
		KeyPairGenerator keyGenerator = KeyPairGenerator.getInstance("RSA");
		keyGenerator.initialize(1024);
		KeyPair kp = keyGenerator.genKeyPair();
		PublicKey publicKey = (PublicKey) kp.getPublic();
		privateKey = (PrivateKey) kp.getPrivate();
		encodedPublicKey = Base64.getEncoder().encodeToString(publicKey.getEncoded());
		token = Jwts.builder()
				//.setExpiration(new Date(2018, 1, 1))
				.setIssuer("test-issuer")
				.setHeaderParam("typ","JWT")
				.setSubject("test-subject")
				.claim("userid", "test-user")
				.signWith(SignatureAlgorithm.RS256, privateKey).compact();

		

    }
	
	@Test
	public void doFilterInternalTestNoHeader() throws ServletException, IOException {
		
		authorizationFilter.doFilterInternal(request, response, filterChain);
		assertEquals(response.getStatus(),401);
		assertTrue(response.getContentAsString().contains("Not Authorized: No JWT token found in request headers"));
		
	}
	
	@Test
	public void doFilterInternalTestNoBearerInHeader() throws ServletException, IOException {
		
		request.addHeader("Authorization", "Basic ");
		authorizationFilter.doFilterInternal(request, response, filterChain);
		assertEquals(response.getStatus(),401);
		assertTrue(response.getContentAsString().contains("Not Authorized: No JWT token found in request headers"));
		
	}
	
	@Test
	public void doFilterInternalTestNoJwtType() throws ServletException, IOException, NoSuchAlgorithmException {
		
		
		
		authorizationFilter.setPublickey(encodedPublicKey);
		authorizationFilter.setIss("test-issuer");
		authorizationFilter.setSub("test-subject");
		String jwt = Jwts.builder()
				//.setExpiration(new Date(2018, 1, 1))
				.setIssuer("test-issuer")
				.setHeaderParam("typ","token")
				.setSubject("test-subject")
				.claim("userid", "test-user")
				.signWith(SignatureAlgorithm.RS256, privateKey).compact();
		request.addHeader("Authorization", "Bearer " + jwt);
		authorizationFilter.doFilterInternal(request, response, filterChain);
		assertEquals(response.getStatus(),401);
		assertTrue(response.getContentAsString().contains("Invalid JWT Type or Algorithm"));
		
	}
	
	@Test
	public void doFilterInternalTestWrongIssuer() throws ServletException, IOException, NoSuchAlgorithmException {
		
		
		
		authorizationFilter.setPublickey(encodedPublicKey);
		authorizationFilter.setIss("test-issuer2");
		authorizationFilter.setSub("test-subject");
		String jwt = token;
		request.addHeader("Authorization", "Bearer " + jwt);
		authorizationFilter.doFilterInternal(request, response, filterChain);
		assertEquals(response.getStatus(),401);
		assertTrue(response.getContentAsString().contains("Invalid JWT Issuer or Subject"));
		
	}
	
	@Test
	public void doFilterInternalTestSuccess() throws ServletException, IOException, NoSuchAlgorithmException {
		
		Set<String> custNbrs = new HashSet<>();
		custNbrs.add("4413");
		ApiConsumer apiConsumer = new ApiConsumer ("user01","test user", custNbrs,"test ultimate cust nbr","");
		Optional<ApiConsumer> apiConsumerOpt = Optional.of(apiConsumer);
		when(apiConsumerRepository.findById(ArgumentMatchers.anyString())).thenReturn(apiConsumerOpt);
		when(consumer.getUserId()).thenReturn("test-user");
		
		authorizationFilter.setPublickey(encodedPublicKey);
		authorizationFilter.setIss("test-issuer");
		authorizationFilter.setSub("test-subject");
		String jwt = token;
		request.addHeader("Authorization", "Bearer " + jwt);
		authorizationFilter.doFilterInternal(request, response, filterChain);
		assertEquals(response.getStatus(),200);
		
	}
	
	@Test
	public void doFilterInternalTestUserNotFound() throws ServletException, IOException, NoSuchAlgorithmException {
		

		Optional<ApiConsumer> apiConsumerOpt = Optional.ofNullable(null);
		when(apiConsumerRepository.findById(ArgumentMatchers.anyString())).thenReturn(apiConsumerOpt);
		
		authorizationFilter.setPublickey(encodedPublicKey);
		authorizationFilter.setIss("test-issuer");
		authorizationFilter.setSub("test-subject");
		String jwt = token;
		request.addHeader("Authorization", "Bearer " + jwt);
		authorizationFilter.doFilterInternal(request, response, filterChain);
		assertEquals(response.getStatus(),401);
		assertTrue(response.getContentAsString().contains("Unauthorized"));
		
	}


}

