package io.lumen.hyperscalers.resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import io.lumen.hyperscalers.orders.constants.Constants;
import io.lumen.hyperscalers.orders.exception.InvalidOrderStatusException;
import io.lumen.hyperscalers.orders.exception.InvalidProductException;
import io.lumen.hyperscalers.orders.model.Consumer;
import io.lumen.hyperscalers.orders.resource.OrderResource;
import io.lumen.hyperscalers.orders.response.IpConfig;
import io.lumen.hyperscalers.orders.response.Milestone;
import io.lumen.hyperscalers.orders.response.Order;
import io.lumen.hyperscalers.orders.response.OrderInformationResponse;
import io.lumen.hyperscalers.orders.response.ServiceOrder;
import io.lumen.hyperscalers.orders.service.OrderInformationService;


@SpringBootTest(classes=OrderResourceTest.class)
@AutoConfigureMockMvc
public class OrderResourceTest {
	private static final Logger logger = LogManager.getLogger(OrderResourceTest.class);

	@InjectMocks
	private OrderResource orderResource;
	@Autowired
	private MockMvc mockMvc;
	@Mock
	private OrderInformationService orderInformationService;
	
		@BeforeEach
		public void setup() throws Exception {
			mockMvc = MockMvcBuilders.standaloneSetup(orderResource).build();    	
	    }
		
		
	  @Test
	  public void testConsumernull()
	  {
		  Optional<List<String>> services= Optional.ofNullable(null);
	      Optional<String> customerOrderNumber=  Optional.ofNullable(null);
	      Optional<List<String>> statuses= Optional.ofNullable(null); 	 
		  Consumer consumer=null;
		  Optional<List<String>> custnbrlstt = Optional.of(new ArrayList<String>());
	      custnbrlstt.get().add(Constants.CUSTNBR);
	      logger.info("custnbrlstt.get() "+custnbrlstt.get());
	     // assertTrue(custnbrlstt.get().equals("4413"));
	      Order or = new Order();
			 or.setCustomerNumber("4413");
	      	 or.setOrderNumber("551822320");
			 ServiceOrder so = new ServiceOrder();
			 so.setActualDeliveryDate(LocalDate.of(2021,03,01).toString());
			 so.setCfaEndA(null);
			 so.setCfaEndZ(null);
			 so.setContractSignedDate(null);
			 so.setCurrentCustomerCommitDate(LocalDate.of(2021,03,04).toString());
			 so.setCustomerOrderNumber("TRIM.20200513.08");
			 so.setDescription("100GIG-E");
			 so.setFirmOrderConfirmationDate(LocalDate.of(2021,03,04).toString());
			 //so.setInstallInterval("45 (days)");
			 IpConfig ipc = new IpConfig();
			 so.setIpConfig(ipc);
			 Milestone ms = new Milestone();
			 ms.setStatus("COMPLETE_REFLECTION");
			 ms.setStartDate(LocalDate.of(2021,02,25).toString());
			 ms.setCompletedDate(LocalDate.of(2021,02,25).toString());
			 ms.setLastUpdatedDate(null);
			 ms.setName("PLAN");
			 Milestone ms1 = new Milestone();
			 ms1.setStatus("COMPLETE_REFLECTION");
			 ms1.setStartDate(LocalDate.of(2021,03,01).toString());
			 ms1.setCompletedDate(LocalDate.of(2021,03,01).toString());
			 ms1.setLastUpdatedDate(null);
			 ms1.setName("DESIGN");
			 Milestone ms2 = new Milestone();
			 ms2.setStatus("COMPLETE_REFLECTION");
			 ms2.setStartDate(LocalDate.of(2021,03,01).toString());
			 ms2.setCompletedDate(LocalDate.of(2021,03,01).toString());
			 ms2.setLastUpdatedDate(null);
			 ms2.setName("BUILD");
			 Milestone ms3 = new Milestone();
			 ms3.setStatus("COMPLETE_REFLECTION");
			 ms3.setStartDate(LocalDate.of(2021,03,01).toString());
			 ms3.setCompletedDate(LocalDate.of(2021,03,01).toString());
			 ms3.setLastUpdatedDate(null);
			 ms3.setName("ACTIVATE");
			 List<Milestone> lstm = new ArrayList<Milestone>();
			 lstm.add(ms);
			 lstm.add(ms1);
			 lstm.add(ms2);
			 lstm.add(ms3);
			 so.setMilestones(lstm);
			 so.setOrderReceivedDate(LocalDate.of(2021,02,25).toString());
			 so.setOriginalRequestedDueDate(LocalDate.of(2021,03,04).toString());
			 so.setService("Wavelength");
			 so.setServiceEndDate(null);
			 so.setServiceId("442250299");
			 so.setServiceType("Wavelength");
			 so.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
			 so.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
			 so.setVendorName("Lumen");
			// so.setCircuitId("442351960");
			 List<String> ci = new ArrayList<>();
		        ci.add("442351960");
		        so.setCircuitIds(ci);
		     List<ServiceOrder> sol = new ArrayList<ServiceOrder>();
		     sol.add(so);
		      or.setServiceOrders(sol);  
	      List<Order> orders= new ArrayList<Order>();
	      orders.add(or);
	      when(orderInformationService.getOrderInformation(services, customerOrderNumber, statuses, custnbrlstt.get())).thenReturn(orders);
	      ResponseEntity<OrderInformationResponse> oir = orderResource.getAllInProgressOrders(services, customerOrderNumber, statuses);
	      //List<Order> orders = ReflectionTestUtils.invokeMethod(orderInformationService,"getOrderInformation", services, customerOrderNumber, statuses, custnbrlstt.get());
	      assertEquals(oir.getStatusCodeValue(), 200);
	      
	  }
	  
	  @Test
	  public void testConsumernotnull()
	  {
		  Optional<List<String>> services= Optional.ofNullable(null);
	      Optional<String> customerOrderNumber=  Optional.ofNullable(null);
	      Optional<List<String>> statuses= Optional.ofNullable(null); 	 
		  Consumer consumer = new Consumer();
		  consumer.setUserId("ac91419");
		  consumer.setAccess("");
		  consumer.setUltCustNbr("1-AEW-2248-UC");
		  Set<String> custnbrs = new HashSet<String>();
		  custnbrs.add("4413");
		  consumer.setCustNbrs(custnbrs);
	      Optional<List<String>> custnbrlstt = Optional.of(consumer.getCustNbrs().stream()
                  .map(Object::toString)
                  .collect(Collectors.toList()));
	      logger.info("custnbrlstt.get() "+custnbrlstt.get());
	     // assertTrue(custnbrlstt.get().equals("4413"));
	      Order or = new Order();
			 or.setCustomerNumber("4413");
	      	 or.setOrderNumber("551822320");
			 ServiceOrder so = new ServiceOrder();
			 so.setActualDeliveryDate(LocalDate.of(2021,03,01).toString());
			 so.setCfaEndA(null);
			 so.setCfaEndZ(null);
			 so.setContractSignedDate(null);
			 so.setCurrentCustomerCommitDate(LocalDate.of(2021,03,04).toString());
			 so.setCustomerOrderNumber("TRIM.20200513.08");
			 so.setDescription("100GIG-E");
			 so.setFirmOrderConfirmationDate(LocalDate.of(2021,03,04).toString());
			 //so.setInstallInterval("45 (days)");
			 IpConfig ipc = new IpConfig();
			 so.setIpConfig(ipc);
			 Milestone ms = new Milestone();
			 ms.setStatus("COMPLETE_REFLECTION");
			 ms.setStartDate(LocalDate.of(2021,02,25).toString());
			 ms.setCompletedDate(LocalDate.of(2021,02,25).toString());
			 ms.setLastUpdatedDate(null);
			 ms.setName("PLAN");
			 Milestone ms1 = new Milestone();
			 ms1.setStatus("COMPLETE_REFLECTION");
			 ms1.setStartDate(LocalDate.of(2021,03,01).toString());
			 ms1.setCompletedDate(LocalDate.of(2021,03,01).toString());
			 ms1.setLastUpdatedDate(null);
			 ms1.setName("DESIGN");
			 Milestone ms2 = new Milestone();
			 ms2.setStatus("COMPLETE_REFLECTION");
			 ms2.setStartDate(LocalDate.of(2021,03,01).toString());
			 ms2.setCompletedDate(LocalDate.of(2021,03,01).toString());
			 ms2.setLastUpdatedDate(null);
			 ms2.setName("BUILD");
			 Milestone ms3 = new Milestone();
			 ms3.setStatus("COMPLETE_REFLECTION");
			 ms3.setStartDate(LocalDate.of(2021,03,01).toString());
			 ms3.setCompletedDate(LocalDate.of(2021,03,01).toString());
			 ms3.setLastUpdatedDate(null);
			 ms3.setName("ACTIVATE");
			 List<Milestone> lstm = new ArrayList<Milestone>();
			 lstm.add(ms);
			 lstm.add(ms1);
			 lstm.add(ms2);
			 lstm.add(ms3);
			 so.setMilestones(lstm);
			 so.setOrderReceivedDate(LocalDate.of(2021,02,25).toString());
			 so.setOriginalRequestedDueDate(LocalDate.of(2021,03,04).toString());
			 so.setService("Wavelength");
			 so.setServiceEndDate(null);
			 so.setServiceId("442250299");
			 so.setServiceType("Wavelength");
			 so.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
			 so.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
			 so.setVendorName("Lumen");
			// so.setCircuitId("442351960");
			 List<String> ci = new ArrayList<>();
		        ci.add("442351960");
		        so.setCircuitIds(ci);
		     List<ServiceOrder> sol = new ArrayList<ServiceOrder>();
		     sol.add(so);
		      or.setServiceOrders(sol);  
	      List<Order> orders= new ArrayList<Order>();
	      orders.add(or);
	      when(orderInformationService.getOrderInformation(services, customerOrderNumber, statuses, custnbrlstt.get())).thenReturn(orders);
	      ResponseEntity<OrderInformationResponse> oir = orderResource.getAllInProgressOrders(services, customerOrderNumber, statuses);
	      //List<Order> orders = ReflectionTestUtils.invokeMethod(orderInformationService,"getOrderInformation", services, customerOrderNumber, statuses, custnbrlstt.get());
	      assertEquals(oir.getStatusCodeValue(), 200);
		  
	  }
	  
	
	   @Test
	   public void actualgetAllInProgressOrders() throws Exception
	   {
		

	    mockMvc.perform(get("/orders"))
	    .andExpect(status().isOk());
	    //.andExpect(content().string("Hellod"));
	    //.andDo(print()).andReturn();;
	   }

	 
	 @Test
	 public void validateParamsTestForInvalidStatus() {
		 
		 Optional <List<String>> optionalProducts = Optional.ofNullable(null);
		 Optional<String> OptionalPON = Optional.ofNullable(null);
		 List<String> statuses = Arrays.asList(new String[] {"xyz"});
		 Optional <List<String>> optionalStatuses = Optional.of(statuses);
		 assertThrows(InvalidOrderStatusException.class, () -> {
			 orderResource.validateParams(optionalProducts, OptionalPON, optionalStatuses);
		 });
		 
	 }
	 
	 @Test
	 public void validateParamsTestForInvalidProduct() {
		 
		 List<String> products = Arrays.asList(new String[] {"xyz"});
		 Optional <List<String>> optionalProducts = Optional.of(products);
		 Optional<String> OptionalPON = Optional.ofNullable(null);
		 Optional <List<String>> optionalStatuses = Optional.ofNullable(null);
		 assertThrows(InvalidProductException.class, () -> {
			 orderResource.validateParams(optionalProducts, OptionalPON, optionalStatuses);
		 });
		 
	 }
	 
	 @Test
	 public void validateParamsTestIgnoreOthersIfPurchaseOrderProvided() {
		 
		 List<String> products = Arrays.asList(new String[] {"xyz"});
		 Optional <List<String>> optionalProducts = Optional.of(products);
		 Optional<String> OptionalPON = Optional.of("abc");
		 List<String> statuses = Arrays.asList(new String[] {"xyz"});
		 Optional <List<String>> optionalStatuses = Optional.of(statuses);
		 orderResource.validateParams(optionalProducts, OptionalPON, optionalStatuses);
		 
	 }

}
