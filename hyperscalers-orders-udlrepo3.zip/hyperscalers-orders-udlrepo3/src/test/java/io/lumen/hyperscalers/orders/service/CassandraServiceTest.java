package io.lumen.hyperscalers.orders.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.io.IOException;
import java.time.LocalDate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.matchers.Any;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.lumen.hyperscalers.orders.entity.hyperscalers.OrderInfo;
import io.lumen.hyperscalers.orders.entity.hyperscalers.OrderInfoKey;
import io.lumen.hyperscalers.orders.repository.hyperscalers.OrderInfoRepository;

public class CassandraServiceTest {

	private static final Logger logger = LogManager.getLogger(CassandraServiceTest.class);
	
    @Mock
    OrderInfoRepository orderInfoRepository;

    @InjectMocks
    private CassandraService casService;
 

    @BeforeEach
    public void setup() {
    	MockitoAnnotations.initMocks(this);    	
    }
    	
    @Test
    void getAllOrdersByCustNbrlstTestSuccess() throws JsonParseException, JsonMappingException, IOException {
    	 
    	List<String> custnbrr =new ArrayList<String>();
    	custnbrr.add("4413");
    	String custnbr="4413";
        OrderInfoKey oik = new OrderInfoKey();
		 oik.setOrderNbr("551822320");
		 oik.setServiceId("442250299");
		 oik.setCustnbr("4413");
		 List<String> lci = new ArrayList<>();
 	     lci.add("442351960");
		 List<OrderInfo> mockOrderInfoLst = Collections.singletonList(new OrderInfo(oik,"Wavelength", "100GIG-E",  
		 LocalDate.of(2021,02,25), LocalDate.of(2021,03,04), LocalDate.of(2021,03,04), LocalDate.of(2021,03,01), 
		 "TRIM.20200513.08", "321", LocalDate.of(2021,03,04),  
		 "21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA", null, "601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA", 
		 null, null, "Lumen", null,lci ,null, null, null, null, null, null, null, null, null, null, null, null, "PLAN", "COMPLETE_REFLECTION", LocalDate.of(2021,02,25), 
		 LocalDate.of(2021,02,25), null, "DESIGN", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, 
		 "BUILD", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, "ACTIVATE", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), 
		 LocalDate.of(2021,03,01), null, "in progress","4413","Wavelength","Wavelength"));
         when(orderInfoRepository.findByCustnbr(custnbr)).thenReturn(mockOrderInfoLst);
        
        List<OrderInfo> actualResponse = casService.getAllOrdersByCustNbrlst(custnbrr);
        OrderInfoKey oik1 = new OrderInfoKey();
		 oik1.setOrderNbr("551822320");
		 oik1.setServiceId("442250299");
		 oik1.setCustnbr("4413");
        OrderInfo oi = new OrderInfo();
        oi.setOrderInfoKey(oik1);
        oi.setServiceType("Wavelength");
        oi.setDescription("100GIG-E");
        oi.setOrderReceivedDt(LocalDate.of(2021, 02, 25));
        oi.setOrigRequestedDueDt(LocalDate.of(2021,03,04));
        oi.setFirmOrderCompletionDt(LocalDate.of(2021,03,04));
        oi.setActualDeliveryDt(LocalDate.of(2021,03,01));
        oi.setCustOrderNbr("TRIM.20200513.08");
        oi.setService("321");
        //oi.setInstallInterval("45 (days)");
        oi.setCurrCustCommitDt(LocalDate.of(2021,03,04));
        oi.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
        oi.setCfaEndA(null);
        oi.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
        oi.setCfaEndZ(null);
        oi.setServiceEndDt(null);
        oi.setVendorName("Lumen");
        oi.setContractSignDt(null);
        oi.setCircuitId(lci);
        oi.setIpconfigAsNumber(null);
        oi.setIpconfigCustomerVlanid(null);
        oi.setIpconfigExportPolicy(null);
        oi.setIpconfigIpVersion(null);
        oi.setIpconfigLanipv4(null);
        oi.setIpconfigLanipv6(null);
        oi.setIpconfigLocalAsNumber(null);
        oi.setIpconfigMaintainer(null);
        oi.setIpconfigRoutingInstance(null);
        oi.setIpconfigStaticRoute(null);
        oi.setIpconfigWanipv4(null);
        oi.setIpconfigWanipv6(null);
        oi.setMilestone1Name("PLAN");
        oi.setMilestone1Status("COMPLETE_REFLECTION");
        oi.setMilestone1StartDt(LocalDate.of(2021,02,25));
        oi.setMilestone1CompletedDt(LocalDate.of(2021,02,25));
        oi.setMilestone1LastUpdatedDt(null);
        oi.setMilestone2Name("DESIGN");
        oi.setMilestone2Status("COMPLETE_REFLECTION");
        oi.setMilestone2StartDt(LocalDate.of(2021,03,01));
        oi.setMilestone2CompletedDt(LocalDate.of(2021,03,01));
        oi.setMilestone2LastUpdatedDt(null);
        oi.setMilestone3Name("BUILD");
        oi.setMilestone3Status("COMPLETE_REFLECTION");
        oi.setMilestone3StartDt(LocalDate.of(2021,03,01));
        oi.setMilestone3CompletedDt(LocalDate.of(2021,03,01));
        oi.setMilestone3LastUpdatedDt(null);
        oi.setMilestone4Name("ACTIVATE");
        oi.setMilestone4Status("COMPLETE_REFLECTION");
        oi.setMilestone4StartDt(LocalDate.of(2021,03,01));
        oi.setMilestone4CompletedDt(LocalDate.of(2021,03,01));
        oi.setMilestone4LastUpdatedDt(null);
        oi.setOrderStatus("in progress");
        oi.setCustnbr("4413");
        oi.setServiceName("Wavelength");
        oi.setServiceNameNormalized("Wavelength");
        List<OrderInfo> expectedres = new ArrayList<OrderInfo>();
        expectedres.add(oi);
        assertTrue(actualResponse.equals(expectedres));
        assertEquals(1, actualResponse.size());

        
    }
    
   @Test
    void getAllOrdersByCustNbrBlanklstTestSuccess() throws JsonParseException, JsonMappingException, IOException {
   	 
	    List<String> custnbrr =new ArrayList<String>();
	   	custnbrr.add("4413");
	   	String custnbr="4413";
    	 List<OrderInfo> mockOrderInfoLst = Collections.singletonList(new OrderInfo(null, "", "", null, null, null, null, 
		 "",  "", null,  "", null, "", null,null, "",null,  null,null, null, null, null, null, null, null, null, null, null, null, null, "", "", null, 
		 null, null, "", "", null, null, null, "", "", null, null, null, "", "", null, null, null, "","","",""));
        when(orderInfoRepository.findByCustnbr(custnbr)).thenReturn(mockOrderInfoLst);
        
        List<OrderInfo> actualResponse = casService.getAllOrdersByCustNbrlst(custnbrr);
       
        OrderInfo oi = new OrderInfo();
        oi.setOrderInfoKey(null);
        oi.setServiceType("");
        oi.setDescription("");
        oi.setOrderReceivedDt(null);
        oi.setOrigRequestedDueDt(null);
        oi.setFirmOrderCompletionDt(null);
        oi.setActualDeliveryDt(null);
        oi.setCustOrderNbr("");
        oi.setService("");
       // oi.setInstallInterval("");
        oi.setCurrCustCommitDt(null);
        oi.setUltimateA("");
        oi.setCfaEndA(null);
        oi.setUltimateZ("");
        oi.setCfaEndZ(null);
        oi.setServiceEndDt(null);
        oi.setVendorName("");
        oi.setContractSignDt(null);
        oi.setCircuitId(null);
        oi.setIpconfigAsNumber(null);
        oi.setIpconfigCustomerVlanid(null);
        oi.setIpconfigExportPolicy(null);
        oi.setIpconfigIpVersion(null);
        oi.setIpconfigLanipv4(null);
        oi.setIpconfigLanipv6(null);
        oi.setIpconfigLocalAsNumber(null);
        oi.setIpconfigMaintainer(null);
        oi.setIpconfigRoutingInstance(null);
        oi.setIpconfigStaticRoute(null);
        oi.setIpconfigWanipv4(null);
        oi.setIpconfigWanipv6(null);
        oi.setMilestone1Name("");
        oi.setMilestone1Status("");
        oi.setMilestone1StartDt(null);
        oi.setMilestone1CompletedDt(null);
        oi.setMilestone1LastUpdatedDt(null);
        oi.setMilestone2Name("");
        oi.setMilestone2Status("");
        oi.setMilestone2StartDt(null);
        oi.setMilestone2CompletedDt(null);
        oi.setMilestone2LastUpdatedDt(null);
        oi.setMilestone3Name("");
        oi.setMilestone3Status("");
        oi.setMilestone3StartDt(null);
        oi.setMilestone3CompletedDt(null);
        oi.setMilestone3LastUpdatedDt(null);
        oi.setMilestone4Name("");
        oi.setMilestone4Status("");
        oi.setMilestone4StartDt(null);
        oi.setMilestone4CompletedDt(null);
        oi.setMilestone4LastUpdatedDt(null);
        oi.setOrderStatus("");
        oi.setCustnbr("");
        oi.setServiceName("");
        oi.setServiceNameNormalized("");
        List<OrderInfo> expectedres = new ArrayList<OrderInfo>();
        expectedres.add(oi);
        assertTrue(actualResponse.get(0).equals(expectedres.get(0)));
        assertEquals(1, actualResponse.size());
    }
    
    @Test
    void getOrdersByCustomerOrderNumberTestSuccess() throws JsonParseException, JsonMappingException, IOException {
   	 
    	List<String> custnbrlst =new ArrayList<String>();
    	custnbrlst.add("4413");
    	String custnbr = "4413";
    	String customerOrderNumber = "TRIM.20200513.08";
    	 OrderInfoKey oik = new OrderInfoKey();
		 oik.setOrderNbr("551822320");
		 oik.setServiceId("442250299");
		 oik.setCustnbr("4413");
		 List<String> lci = new ArrayList<>();
 	     lci.add("442351960");
		 List<OrderInfo> mockOrderInfoLst = Collections.singletonList(new OrderInfo(oik, "Wavelength", "100GIG-E",  
		LocalDate.of(2021,02,25), LocalDate.of(2021,03,04), LocalDate.of(2021,03,04), LocalDate.of(2021,03,01), 
		"TRIM.20200513.08", "321", LocalDate.of(2021,03,04),  
		"21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA", null, "601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA", 
		null, null, "Lumen", null, lci , null, null, null, null, null, null, null, null, null, null, null, null, "PLAN", "COMPLETE_REFLECTION", LocalDate.of(2021,02,25), 
		LocalDate.of(2021,02,25), null, "DESIGN", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, 
		"BUILD", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), LocalDate.of(2021,03,01), null, "ACTIVATE", "COMPLETE_REFLECTION", LocalDate.of(2021,03,01), 
		LocalDate.of(2021,03,01), null, "in progress","4413","Wavelength","Wavelength"));
    	when(orderInfoRepository.findBycustOrderNbrAndCustnbr(customerOrderNumber, custnbr)).thenReturn(mockOrderInfoLst);
        List<OrderInfo> actualResponse = casService.getOrdersByCustomerOrderNumber(customerOrderNumber, custnbrlst);
       
        OrderInfo oi = new OrderInfo();
        OrderInfoKey oik1 = new OrderInfoKey();
		 oik1.setOrderNbr("551822320");
		 oik1.setServiceId("442250299");
		 oik1.setCustnbr("4413");
		oi.setOrderInfoKey(oik1);
        oi.setServiceType("Wavelength");
        oi.setDescription("100GIG-E");
        oi.setOrderReceivedDt(LocalDate.of(2021, 02, 25));
        oi.setOrigRequestedDueDt(LocalDate.of(2021,03,04));
        oi.setFirmOrderCompletionDt(LocalDate.of(2021,03,04));
        oi.setActualDeliveryDt(LocalDate.of(2021,03,01));
        oi.setCustOrderNbr("TRIM.20200513.08");
       
        oi.setService("321");
        //oi.setInstallInterval("45 (days)");
        oi.setCurrCustCommitDt(LocalDate.of(2021,03,04));
        oi.setUltimateA("21005 LAHSER RD Floor 1 Room MMR2 SOUTHFIELD MICHIGAN 48033 USA");
        oi.setCfaEndA(null);
        oi.setUltimateZ("601 NORTHWEST AVE Floor 1 Room MMR NORTHLAKE ILLINOIS 60164 USA");
        oi.setCfaEndZ(null);
        oi.setServiceEndDt(null);
        oi.setVendorName("Lumen");
        oi.setContractSignDt(null);
        oi.setCircuitId(lci);
        oi.setIpconfigAsNumber(null);
        oi.setIpconfigCustomerVlanid(null);
        oi.setIpconfigExportPolicy(null);
        oi.setIpconfigIpVersion(null);
        oi.setIpconfigLanipv4(null);
        oi.setIpconfigLanipv6(null);
        oi.setIpconfigLocalAsNumber(null);
        oi.setIpconfigMaintainer(null);
        oi.setIpconfigRoutingInstance(null);
        oi.setIpconfigStaticRoute(null);
        oi.setIpconfigWanipv4(null);
        oi.setIpconfigWanipv6(null);
        oi.setMilestone1Name("PLAN");
        oi.setMilestone1Status("COMPLETE_REFLECTION");
        oi.setMilestone1StartDt(LocalDate.of(2021,02,25));
        oi.setMilestone1CompletedDt(LocalDate.of(2021,02,25));
        oi.setMilestone1LastUpdatedDt(null);
        oi.setMilestone2Name("DESIGN");
        oi.setMilestone2Status("COMPLETE_REFLECTION");
        oi.setMilestone2StartDt(LocalDate.of(2021,03,01));
        oi.setMilestone2CompletedDt(LocalDate.of(2021,03,01));
        oi.setMilestone2LastUpdatedDt(null);
        oi.setMilestone3Name("BUILD");
        oi.setMilestone3Status("COMPLETE_REFLECTION");
        oi.setMilestone3StartDt(LocalDate.of(2021,03,01));
        oi.setMilestone3CompletedDt(LocalDate.of(2021,03,01));
        oi.setMilestone3LastUpdatedDt(null);
        oi.setMilestone4Name("ACTIVATE");
        oi.setMilestone4Status("COMPLETE_REFLECTION");
        oi.setMilestone4StartDt(LocalDate.of(2021,03,01));
        oi.setMilestone4CompletedDt(LocalDate.of(2021,03,01));
        oi.setMilestone4LastUpdatedDt(null);
        oi.setOrderStatus("in progress");
        oi.setCustnbr("4413");
        oi.setServiceName("Wavelength");
        oi.setServiceNameNormalized("Wavelength");
        List<OrderInfo> expectedres = new ArrayList<OrderInfo>();
        expectedres.add(oi);
        assertTrue(actualResponse.equals(expectedres));
        assertEquals(1, actualResponse.size());
    }
    
    @Test
    void getOrdersByCustomerOrderNumberBlankTestSuccess() throws JsonParseException, JsonMappingException, IOException {
   	 
    	List<String> custnbrlst =new ArrayList<String>();
    	custnbrlst.add("4413");
    	String custnbr = "4413";
        String customerOrderNumber = "TRIM.20200513.08";
    	 List<OrderInfo> mockOrderInfoLst = Collections.singletonList(new OrderInfo(null, "", "", null, null, null, null, 
		 "",  "", null,  "", null, "", null, null, "", null, null,null, null, null, null, null, null, null, null, null, null, null, null, "", "", null, 
		 null, null, "", "", null, null, null, "", "", null, null, null, "", "", null, null, null, "","","",""));
    	 when(orderInfoRepository.findBycustOrderNbrAndCustnbr(customerOrderNumber, custnbr)).thenReturn(mockOrderInfoLst);
        
        List<OrderInfo> actualResponse = casService.getOrdersByCustomerOrderNumber(customerOrderNumber, custnbrlst);
       
        OrderInfo oi = new OrderInfo();
        oi.setOrderInfoKey(null);
        oi.setServiceType("");
        oi.setDescription("");
        oi.setOrderReceivedDt(null);
        oi.setOrigRequestedDueDt(null);
        oi.setFirmOrderCompletionDt(null);
        oi.setActualDeliveryDt(null);
        oi.setCustOrderNbr("");
        oi.setService("");
        //oi.setInstallInterval("");
        oi.setCurrCustCommitDt(null);
        oi.setUltimateA("");
        oi.setCfaEndA(null);
        oi.setUltimateZ("");
        oi.setCfaEndZ(null);
        oi.setServiceEndDt(null);
        oi.setVendorName("");
        oi.setContractSignDt(null);
        oi.setCircuitId(null);
        oi.setIpconfigAsNumber(null);
        oi.setIpconfigCustomerVlanid(null);
        oi.setIpconfigExportPolicy(null);
        oi.setIpconfigIpVersion(null);
        oi.setIpconfigLanipv4(null);
        oi.setIpconfigLanipv6(null);
        oi.setIpconfigLocalAsNumber(null);
        oi.setIpconfigMaintainer(null);
        oi.setIpconfigRoutingInstance(null);
        oi.setIpconfigStaticRoute(null);
        oi.setIpconfigWanipv4(null);
        oi.setIpconfigWanipv6(null);
        oi.setMilestone1Name("");
        oi.setMilestone1Status("");
        oi.setMilestone1StartDt(null);
        oi.setMilestone1CompletedDt(null);
        oi.setMilestone1LastUpdatedDt(null);
        oi.setMilestone2Name("");
        oi.setMilestone2Status("");
        oi.setMilestone2StartDt(null);
        oi.setMilestone2CompletedDt(null);
        oi.setMilestone2LastUpdatedDt(null);
        oi.setMilestone3Name("");
        oi.setMilestone3Status("");
        oi.setMilestone3StartDt(null);
        oi.setMilestone3CompletedDt(null);
        oi.setMilestone3LastUpdatedDt(null);
        oi.setMilestone4Name("");
        oi.setMilestone4Status("");
        oi.setMilestone4StartDt(null);
        oi.setMilestone4CompletedDt(null);
        oi.setMilestone4LastUpdatedDt(null);
        oi.setOrderStatus("");
        oi.setCustnbr("");
        oi.setServiceName("");
        oi.setServiceNameNormalized("");
        List<OrderInfo> expectedres = new ArrayList<OrderInfo>();
        expectedres.add(oi);
        assertTrue(actualResponse.get(0).equals(expectedres.get(0)));
        assertEquals(1, actualResponse.size());
    }
    
}
