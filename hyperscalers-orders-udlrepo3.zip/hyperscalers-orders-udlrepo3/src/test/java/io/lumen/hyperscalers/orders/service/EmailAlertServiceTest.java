package io.lumen.hyperscalers.orders.service;


import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.Properties;

import javax.mail.Session;
import javax.mail.internet.MimeMessage;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.javamail.JavaMailSender;




@SpringBootTest(classes = EmailAlertServiceTest.class)
public class EmailAlertServiceTest {	
	@Mock
	private JavaMailSender mailSender;
	
	@Mock
	private MimeMessage mimeMessage;
	
	@InjectMocks
	private EmailAlertService emailService;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);

		doNothing().when(mailSender).send(Mockito.any(MimeMessage.class));
		when(mailSender.createMimeMessage()).thenReturn(new MimeMessage(Session.getDefaultInstance(new Properties())));
		emailService.recipients = "test@email.com";
		emailService.sender = "noreply@email.com";
	}
	
	@Test
	public void testSendEmailNotification() {
		
		when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
		doNothing().when(mailSender).send(mimeMessage);
		emailService.sendEmailNotification("Orders Api completed", "ORDERS_API_SUCCESS_ALERT_SUBJECT");
		
	}
	
	
	
	 
	 @Test
		public void testSendEmailNotificationException() {
			try {
				emailService.recipients = null;
				emailService.sendEmailNotification("Test", "TEST");
			} catch (Exception e) {
				assertTrue(e instanceof NullPointerException);
			}
		}   

	
	
}