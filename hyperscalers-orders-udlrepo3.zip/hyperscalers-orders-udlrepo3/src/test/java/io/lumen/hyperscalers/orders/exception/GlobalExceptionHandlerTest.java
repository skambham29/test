package io.lumen.hyperscalers.orders.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import io.lumen.hyperscalers.orders.response.OrderInformationException;

public class GlobalExceptionHandlerTest {
	
	GlobalExceptionHandler globalExceptionHandler;
	
	@BeforeEach
	public void setUp() {
		globalExceptionHandler = new GlobalExceptionHandler();
	}
	
	@Test
	public void handleInvalidProductExceptionTest() {
		InvalidProductException e = new InvalidProductException("invalid-product");
		
		ResponseEntity<OrderInformationException> response = globalExceptionHandler.handleInvalidProductException(e);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
	
	@Test
	public void handleInvalidStatusExceptionTest() {
		InvalidOrderStatusException e = new InvalidOrderStatusException("invalid-status");
		
		ResponseEntity<OrderInformationException> response = globalExceptionHandler.handleInvalidStatusException(e);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
	
	@Test
	public void handleOrderNotFoundExceptionTest() {
		OrderNotFoundException e = new OrderNotFoundException("order-number");
		
		ResponseEntity<OrderInformationException> response = globalExceptionHandler.handleOrderNotFoundException(e);
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
	}

}
