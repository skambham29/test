#!/bin/bash
# -------------------------------------------------------------
# This script is a wrapper around the automated deployment process.
# Its job is to control the deployment process and call the necessary
# scripts to get the job done
#
# Arguments:
# $1 - The environment to deploy for
# $2 - password for weblogic
#
# Author: Franz Garsombke 06/04/06
# Modified: Jeffrey Scelza 7-4-06
# --------------------------------------------------------------
# check parms
# --------------------------------------------------------------

if [ "$#" -lt 2 ]
then
  echo "Incorrect number of arguments."
  echo "Usage: deploydriver.sh environment weblogic_password"
  exit 1
fi

# Set Arguments
echo "Setting generic variables..."
PANDA_DIR=`pwd`
ENVIRONMENT=$1
PASSWORD=$2
WLS_USER=weblogic
### From Application specific directory ###
ENV_FILE_NAME="${PANDA_DIR}/env_config/default_deploydriver.properties" #${ENVIRONMENT}_deploy.properties"
#BEA_FILE_NAME="${PANDA_DIR}/env_config/${ENVIRONMENT}_bea.properties"
### Found in gpscommon directory ###
FUN_FILE_NAME="${PANDA_DIR}/deploy_scripts/deployFunctions.sh_include"
PROFILE_FILE_NAME="${PANDA_DIR}/deploy_scripts/.profile"
FUNCTION_SCRIPT="${PANDA_DIR}/deploy_scripts/deploy_functions.sh"


# --------------------------------------------------------------
# source properties files
# --------------------------------------------------------------
echo "Sourcing functions..."
dos2unix ${FUN_FILE_NAME} ${FUN_FILE_NAME} >> /dev/null 2>&1
. ${FUN_FILE_NAME}
commandCheck "$?" "${FUN_FILE_NAME} has a syntax error, exiting..."

echo "Sourcing envuser's profile contain in gpscommon..."
. ${PROFILE_FILE_NAME}
commandCheck "$?" "${PROFILE_FILE_NAME} has a syntax error, exiting..."

echo "Sourcing script's properties..."
dos2unix ${ENV_FILE_NAME} ${ENV_FILE_NAME} 2> /dev/null
. ${ENV_FILE_NAME}
commandCheck "$?" "${ENV_FILE_NAME} has a syntax error, exiting..."

echo "Sourcing deploy functions script..."
dos2unix ${FUNCTION_SCRIPT} ${FUNCTION_SCRIPT} 2> /dev/null
. ${FUNCTION_SCRIPT}
commandCheck "$?" "${FUNCTION_SCRIPT} has a syntax error, exiting..."

#dos2unix ${BEA_FILE_NAME} ${BEA_FILE_NAME} 2> /dev/null
#commandCheck "$?" "${BEA_FILE_NAME} not found, exiting..."

# --------------------------------------------------------------
# Main
# --------------------------------------------------------------
echo "Environment is ${ENVIRONMENT}..."
echo "The DOMAIN_DIR is ${DOMAIN_DIR}..."

echo "Currently Running Apps are..."
sudo su - ${UNIX_USER} -c "${JAVA_HOME}/bin/java -cp ${WLST_CP} weblogic.Deployer  -adminurl $ADMIN_URL -user ${WLS_USER} -password $PASSWORD -listapps" 

commandCheck "$?" "Can not connect to ${ADMIN_URL}, exit..."

echo "Building necessary jars..."
buildlibrary
commandCheck "$?" "custom jar build failed, exit..."
echo "Done building jars..."

echo "Undeploying Applications..."
loopAction "${SOFTWARE_MODULES}" "${WLS_TARGETS}" undeployModule
echo "Done undeploying applications!"

echo "Copying Application"
loopAction "${SOFTWARE_MODULES}" "${WLS_TARGETS}" copySoftware
echo "Done copying Software files!"

echo "Deploying Application"
loopAction "${SOFTWARE_MODULES}" "${WLS_TARGETS}" deploySoftwareModule
echo "Done deploying!"

echo "Restarting All nodes..."
sudo su - ${UNIX_USER} -c "${DOMAIN_DIR}/domainctl rolling ${PASSWORD}"
commandCheck "$?" "Restart failed, exit..."
echo "Done restarting nodes..."

echo "Done running deploy script!"
