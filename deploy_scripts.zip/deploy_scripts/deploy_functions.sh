#!/bin/bash
################################################################################
#                                                                              #
# This script contains reusable functions for deploying applications to        #
#  WebLogic application servers.                                               #
#                                                                              #
# Arguments:                                                                   #
#                                                                              #
# Author: Ken Rumer - 9/21/2010                                                #
#                                                                              #
################################################################################

undeploy_module () {
    ADMIN_URL=$1
    USER_NAME=$2
    PASSWD=$3
    SERVICE_MODULE=$4

    OUTPUT=`java -cp $WLST_CP weblogic.Deployer -adminurl ${ADMIN_URL} -user ${USER_NAME} -password ${PASSWD} -name ${SERVICE_MODULE} -undeploy`
    if [ $? -ne 0 ]; then
      echo "WARNING: failed to undeploy $SERVICE_MODULE..."
      echo "$OUTPUT"
    fi
}

deploy_module () {
    ADMIN_URL=$1
    USER_NAME=$2
    PASSWD=$3
    DIST_DIR=$4
    DOMAIN_HOME=$5
    SERVICE_MODULE=$6
    TARGETS=$7
    SERVICE_FILE=$8 #OPTIONAL

    if [ -z "$SERVICE_FILE" ]; then
      SERVICE_FILE=`ls -1 ${DIST_DIR}/ | grep ${SERVICE_MODULE}.*ar`
    fi
    rm -f ${DOMAIN_HOME}/applications/${SERVICE_FILE}
    cp ${DIST_DIR}/${SERVICE_FILE} ${DOMAIN_HOME}/applications/
    OUTPUT=`java -cp $WLST_CP weblogic.Deployer -timeout 900 -adminurl ${ADMIN_URL} -user ${USER_NAME} -password ${PASSWD} -name ${SERVICE_MODULE} -targets "${TARGETS}" -stage -deploy "${DOMAIN_HOME}/applications/${SERVICE_FILE}"`
    if [ $? -ne 0 ]; then
      echo "Failed to deploy $SERVICE_MODULE..."
      echo "$OUTPUT"
      exit 1
    fi
}

stop_module () {
    ADMIN_URL=$1
    USER_NAME=$2
    PASSWD=$3
    SERVICE_MODULE=$4

    OUTPUT=`java -cp $WLST_CP weblogic.Deployer -adminurl ${ADMIN_URL} -user ${USER_NAME} -password ${PASSWD} -name ${SERVICE_MODULE} -stop`
    if [ $? -ne 0 ]; then
      echo "WARNING: Failed to stop $SERVICE_MODULE..."
      echo "$OUTPUT"
    fi
}

start_module () {
    ADMIN_URL=$1
    USER_NAME=$2
    PASSWD=$3
    SERVICE_MODULE=$4

    OUTPUT=`java -cp $WLST_CP weblogic.Deployer -adminurl ${ADMIN_URL} -user ${USER_NAME} -password ${PASSWD} -name ${SERVICE_MODULE} -start`
    if [ $? -ne 0 ]; then
      echo "Failed to start $SERVICE_MODULE..."
      echo "$OUTPUT"
      exit 1
    fi
}

# Replaces instances of $1 with $2
# i.e. cat <file> | replace @@env@@ $environment
replace () {
    SEARCH=$1
    REPLACE=$2

    while read data; do
      echo "$data" | sed "s/$SEARCH/$REPLACE/g"
    done
}

filter_files () {
    ENVIRONMENT=$1
    PASSWD=$2
    PANDA_DIR=$3
    BUILD_FILE=$4
    TARGET=$5
    EXT_PROPERTIES=$6 #OPTIONAL

    PROPERTIES="\
 -Denvironment=${ENVIRONMENT}\
 -Dpasswd=${PASSWD}\
 -Dpanda_dir=${PANDA_DIR}\
 -Duser_name=${USER_NAME}\
 -Dwls_user=${WLS_USER}\
 -Dpasswd=${PASSWD}\
 -Dwls_pw=${WLS_PW}\
 -Ddomain_name=${DOMAIN_NAME}\
 -Dserver_name=${SERVER_NAME}\
 -Dadmin_server=${ADMIN_SERVER}\
 -Dadmin_port=${ADMIN_PORT}\
 -Dnumber_of_nodes=${NUMBER_OF_NODES}\
 -Djava_home=${JAVA_HOME}\
 -Djava_vendor=${JAVA_VENDOR}\
 -Ddomain_home=${DOMAIN_HOME}\
 -Dlog_dir=${LOG_DIR}\
 -Dwls_redirect_log=${WLS_REDIRECT_LOG}\
 -Dwls_stdout_log=${WLS_STDOUT_LOG}\
 -Dwls_stderr_log=${WLS_STDERR_LOG}\
 -Dpid_file=${PID_FILE}\
 -Dlog4j_config_file=${LOG4J_CONFIG_FILE}\
 -Dstop_script=${STOP_SCRIPT}\
 -Dstart_script=${START_SCRIPT}\
 -Dext_pre_classpath=${EXT_PRE_CLASSPATH}\
 -Dext_post_classpath=${EXT_POST_CLASSPATH}\
 -Dbea_home=${BEA_HOME}\
 -Dwl_home=${WL_HOME}\
 -Dwls_home=${WLS_HOME}\
 -Dld_library_path=${LD_LIBRARY_PATH}\
 -Dpath=${PATH}"

    if [ -n "${EXT_PROPERTIES}" ]; then
      PROPERTIES="${PROPERTIES} ${EXT_PROPERTIES}"
    fi
	echo "filter_files PROPERTIES is ${PROPERTIES}"

    echo "deploy_functions target is ${TARGET}"
    echo "deploy_functions build_file is ${BUILD_FILE}"

    CLASSPATH=${ANT_CP};${ANT_HOME}/bin/ant -buildfile $BUILD_FILE $PROPERTIES $TARGET 2>&1 | tee ./ant.log
    result=`tail ./ant.log  | grep BUILD | cut -f2 -d" "`
    if [ "$result" != "SUCCESSFUL" ]; then
      echo "Ant target ${TARGET} failed...."
      exit 1
    fi
    rm ./ant.log

}

copy_local_files () {
    ENVIRONMENT=$1
    PASSWD=$2
    PANDA_DIR=$3
    SOURCE_FILE="$4"
    DEST_FILE=$5
    BUILD_FILE=$6 #OPTIONAL
    TARGET=$7 #OPTIONAL

    cd ${PANDA_DIR}
    if echo ${DEST_FILE} | grep /$ 1>/dev/null 2>&1; then
      dest_dir=${DEST_FILE}
    else
      dest_dir=`dirname ${DEST_FILE}`
    fi
    mkdir -p ${dest_dir} 2>/dev/null
    cp -r ./${SOURCE_FILE} ${DEST_FILE}
    if [ -n "${BUILD_FILE}" ]; then
      filter_files $ENVIRONMENT $PASSWD $PANDA_DIR $BUILD_FILE $TARGET
    fi
}

extract_jar () {
    PANDA_DIR=$1
    JAR_FILE=$2
    EXTRACT_DIR=$3
    jar_dir=`dirname ${JAR_FILE}`
    jar_file_name=`basename ${JAR_FILE}`

	ls -l ${jar_dir}
	if [ -s ${JAR_FILE} ]; then
	    cd ${PANDA_DIR}
	    mkdir -p ${EXTRACT_DIR}
	    cd ${EXTRACT_DIR}
	    ${JAVA_HOME}/bin/jar xvf ${JAR_FILE}
	    cd ${PANDA_DIR}
	else
		echo "JAR file not found: ${JAR_FILE}. Check your *_deploydriver.properties files."
		exit 1
	fi 
}

create_jar () {
    PANDA_DIR=$1
    JAR_FILE=$2
    CREATE_DIR=$3

    jar_dir=`dirname ${JAR_FILE}`
    jar_file_name=`basename ${JAR_FILE}`

    cd ${PANDA_DIR}
    mkdir -p ${PANDA_DIR}/${jar_dir}
    cd ${PANDA_DIR}/${jar_dir}
    ${JAVA_HOME}/bin/jar cf ${jar_file_name} -C ${PANDA_DIR}/${CREATE_DIR} .
    cd ${PANDA_DIR}
	echo "Created jar ${jar_file}"
}

update_ear () {
    PANDA_DIR=$1
    ear_file=$2
    jar_file=$3
    
	cd ${PANDA_DIR}
	echo "Updating $ear_file with jar: ${jar_file}" 
	if [ ! -s ${ear_file} ]; then
		echo "EAR file not found: ${ear_file}. Check your *_deploydriver.properties files."
		exit 1
	fi 
	if [ ! -s ${jar_file} ]; then
		echo "File to update in ear not found: ${jar_file}. Check your *_deploydriver.properties files."
		exit 1
	fi 
	${JAVA_HOME}/bin/jar -uvf ${ear_file} ${jar_file}
	cd -
}
  
change_deployorder () {
    ADMIN_URL=$1
    USER_NAME=$2
    PASSWD=$3
    SERVICE_MODULE=$4
    DEPLOYORDER=$5

    OUTPUT=`java -cp $WLST_CP weblogic.WLST ${PANDA_DIR}/deploy_scripts/deployOrder.jy $1 $2 $3 $4 $5`
    if [ $? -ne 0 ]; then
      echo "WARNING: Failed to change deploy order for $SERVICE_MODULE..."
      echo "$OUTPUT"
    fi
}
