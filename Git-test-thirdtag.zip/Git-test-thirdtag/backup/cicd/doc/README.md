## Jenkins Pipelines

[Legacy Jenkins](http://jenkinsscmidc01-prod.idc1.level3.com:8080/view/RUDRA/job/RUDRA/job/janus-rudra-services-navigation/) can be reached with CTL Global Protect VPN only. Log in with CUID credentials.

### Pull requests

Pull requests are handled with a multibranch pipeline [here] (http://jenkinsscmidc01-prod.idc1.level3.com:8080/view/RUDRA/job/RUDRA/job/janus-rudra-services-navigation/job/janus-rudra-services-navigation/)

* Pipeline configuration :
    * Multibranch pipeline job configuration details [here](./janus-rudra-services-navigation.xml)
    * Jenkinsfile available [here] (../jenkins/Jenkinsfile) 

### Pull request garbage collector

Garbage from closed pull requests is handled with a multibranch pipeline [here] (http://jenkinsscmidc01-prod.idc1.level3.com:8080/view/RUDRA/job/RUDRA/job/janus-rudra-services-navigation/job/janus-rudra-services-navigation_garbage_collector/)

* Pipeline configuration :
    * Multibranch pipeline job configuration details [here] (./janus-rudra-services-navigation_garbage_collector.xml)
    * Jenkinsfile available  [here] (../jenkins/prune/Jenkinsfile)

